# LiveSync India: Concert & Event Management System
**Enterprise Concert Ticketing & Stage Telemetry Platform**  
*Aligned with DBMS Level 3 Project Specifications (SQL + NoSQL Dual Architecture)*

---

## 1. System Overview & Role-Based Access Control

LiveSync India is a concert ticketing and stage operations platform built with a commercial design. The system implements role-based authorization across two user tiers:

| Role | Default Credentials | Granted Capabilities & Views |
| :--- | :--- | :--- |
| **Customer / User** | **Username**: `arjun`<br>**Password**: `user123` | &bull; **Concerts & Venues**: Browse Indian festivals & stadium shows.<br>&bull; **Book Tickets**: Reserve seats with real-time availability in INR (₹).<br>&bull; **My Bookings**: View active tickets, seat allocations, and receipts. |
| **Administrator** | **Username**: `admin`<br>**Password**: `admin123` | &bull; **Master Registry**: View all attendee bookings across India.<br>&bull; **Event Cancellation**: Cancel concerts and cascade automated refunds.<br>&bull; **Financial Analytics**: Real-time revenue, artist payouts, budgets, and net profit.<br>&bull; **Artist Riders**: Backstage audio/hospitality specs (MongoDB).<br>&bull; **Stage Telemetry**: Real-time IoT decibel & thermal monitoring (MongoDB).<br>&bull; **Admin Approvals**: Authorize user elevation requests. |

---

## 2. Administrator Approval Workflow

To ensure organizational security, users cannot unilaterally self-assign administrator privileges:

1. **Submission**: A customer or operations contractor accesses the **"Request Admin Access"** tab on the login portal and submits their Employee Code, Department, and Operational Justification.
2. **Database Logging**: A record is created in the `admin_request` relational table with `status = 'PENDING'`.
3. **Senior Admin Review**: A currently logged-in Administrator navigates to **"Admin Approvals"** where all pending requests are listed.
4. **Elevation**: Upon clicking **"Approve Elevation"**, the system updates the applicant's role in `app_user` from `USER` to `ADMIN`, immediately granting administrative privileges upon their next session.

---

## 3. Database Architecture & Level 3 Project Alignment

The database design strictly satisfies the PES University Level 3 Project requirements:

### A. Relational Database (PostgreSQL)
* **DDL Implementation**: Tables created with PRIMARY KEY, FOREIGN KEY, NOT NULL, and CHECK constraints (`max_capacity > 0`, `price >= 0`, `fee >= 0`, `budget >= 0`).
* **Entity Relationships**:
  * Unary Recursive Relationship (`SUB_EVENTS` on `concert` via `parent_concert_id`).
  * M:N Relationships (`performs_at` between concerts and venues; `works_on_stage` between organizers and concerts).
  * Strict 1:1 Relationship (`booking` and `ticket` via `ticket_code UNIQUE`).
* **Advanced Database Features**:
  1. **ACID Transaction (`book_ticket_transaction`)**: Executes row-level locking via `SELECT ... FOR UPDATE` on `ticket` rows, enforces venue capacity check, inserts 1:1 `booking`, increments attendee `renewal_count`, and writes to `audit_log` atomically.
  2. **Stored Procedure (`cancel_concert_and_refund`)**: Administrative workflow cascading cancellations to `ticket` (`REFUNDED`), `booking` (`REFUNDED`), and writing audit logs.
  3. **Triggers**:
     * `trg_booking_sync_attendees`: Recalculates and maintains the derived attribute `CONCERT.total_attendees` after any booking change.
     * `trg_enforce_capacity`: Database-level validation preventing ticket status from changing to `BOOKED` if venue capacity is exceeded.
  4. **Complex View (`view_concert_performance_analytics`)**: Joins `concert`, `venue`, `ticket`, `booking`, `artist_booking`, and `promotion` to compute occupancy rates, gross revenue, artist fees, marketing costs, and net profit in INR (₹).

### B. NoSQL Database (MongoDB)
* **`artist_riders`**: Flexible document store managing complex, polymorphic technical requirements (audio channels, monitor mixes, grand piano specs, clip-on dhol mics) and hospitality requests without creating dozens of sparse, NULL-heavy columns in SQL.
* **`stage_sensor_logs`**: High-throughput time-series collection storing real-time telemetry from stage IoT sensors (sound pressure dB levels, stage heat, air quality, pyrotechnic interlock flags).

---

## 4. How to Run the Application

```powershell
# 1. Navigate to the project root
cd "C:\Users\julia\.gemini\antigravity\scratch\livesync-concert-system"

# 2. Start the server
node server.js
```

1. Open **`http://localhost:3000`** in your browser.
2. Sign in using:
   * **Customer**: `arjun` / `user123`
   * **Admin**: `admin` / `admin123`
