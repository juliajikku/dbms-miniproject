/**
 * LiveSync India: Concert & Event Management System
 * Database Client & Unified Data Access Layer
 * File: database/db.js
 */

const { sampleArtistRiders, sampleStageSensorLogs } = require('./nosql_schema');

let Pool = null;
let MongoClient = null;
try { Pool = require('pg').Pool; } catch (e) {}
try { MongoClient = require('mongodb').MongoClient; } catch (e) {}

const PG_CONNECTION_STRING = process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/livesync_db';
const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const MONGO_DB_NAME = process.env.MONGO_DB_NAME || 'livesync_nosql';

let pgPool = null;
let mongoClient = null;
let mongoDb = null;
let isPostgresConnected = false;
let isMongoConnected = false;

// ============================================================================
// DATA STORE
// ============================================================================
const memoryStore = {
  app_users: [
    {
      user_id: 1,
      username: 'admin',
      email: 'admin@livesync.in',
      password_hash: 'admin123',
      full_name: 'System Administrator',
      role: 'ADMIN',
      attendee_id: null
    },
    {
      user_id: 2,
      username: 'arjun',
      email: 'arjun@livesync.in',
      password_hash: 'user123',
      full_name: 'Arjun Sharma',
      role: 'USER',
      attendee_id: 1
    }
  ],
  admin_requests: [
    {
      request_id: 1,
      user_id: 2,
      full_name: 'Arjun Sharma',
      email: 'arjun@livesync.in',
      department: 'Live Operations & Staging',
      employee_code: 'EMP-OPS-402',
      reason: 'Requesting administrative privileges to oversee stage equipment, manage venue bookings, and review event financials.',
      status: 'PENDING',
      reviewed_by: null,
      created_at: new Date('2026-11-01T12:00:00Z')
    }
  ],
  venues: [
    { venue_id: 1, venue_name: 'D.Y. Patil Stadium', max_capacity: 55000, locations: 'Sector 7, Nerul, Navi Mumbai, Maharashtra', renewal_count: 5 },
    { venue_id: 2, venue_name: 'Palace Grounds Arena', max_capacity: 25000, locations: 'Bellary Road, Jayamahal, Bengaluru, Karnataka', renewal_count: 4 },
    { venue_id: 3, venue_name: 'Indira Gandhi Indoor Stadium', max_capacity: 14000, locations: 'Indraprastha Estate, ITO, New Delhi, Delhi', renewal_count: 3 },
    { venue_id: 4, venue_name: 'HillTop Vagator Open-Air', max_capacity: 6000, locations: 'Ozran Beach Road, Vagator, Goa', renewal_count: 2 }
  ],
  organizers: [
    { organizer_id: 1, name: 'LiveSync India Entertainment Ltd', location: 'Bandra West, Mumbai, Maharashtra' },
    { organizer_id: 2, name: 'Sonic Beats Event Corp', location: 'Koramangala, Bengaluru, Karnataka' },
    { organizer_id: 3, name: 'Heritage Stagecraft Delhi', location: 'Connaught Place, New Delhi, Delhi' }
  ],
  concerts: [
    {
      concert_id: 1,
      event_title: 'Sunburn Horizon Electronic Fest 2026',
      date: '2026-11-15',
      time: '18:00:00',
      type: 'Electronic Music Festival',
      city: 'Goa',
      region: 'Western Zone',
      event_desc: 'The flagship electronic music festival featuring top Indian & international bass producers, immersive spatial audio, and high-power laser staging.',
      status: 'Scheduled',
      total_attendees: 0,
      category: 'Flagship Festival',
      ssn: 'GST-GOA-9021',
      parent_concert_id: null
    },
    {
      concert_id: 2,
      event_title: 'Sunburn: Midnight Acoustic Chill Afterparty',
      date: '2026-11-15',
      time: '23:30:00',
      type: 'Afterparty',
      city: 'Goa',
      region: 'Western Zone',
      event_desc: 'Exclusive VIP chill-out acoustic and ambient electronic session with sitar and synth fusion.',
      status: 'Scheduled',
      total_attendees: 0,
      category: 'Sub-Stage',
      ssn: 'GST-GOA-9021',
      parent_concert_id: 1
    },
    {
      concert_id: 3,
      event_title: 'Raag & Symphony: Classical Fusion Live',
      date: '2026-11-22',
      time: '19:00:00',
      type: 'Classical Fusion',
      city: 'New Delhi',
      region: 'Northern Zone',
      event_desc: 'A grand fusion orchestra blending traditional Indian ragas with a 50-piece contemporary symphonic ensemble.',
      status: 'Scheduled',
      total_attendees: 0,
      category: 'Hall Premiere',
      ssn: 'GST-DEL-4402',
      parent_concert_id: null
    },
    {
      concert_id: 4,
      event_title: 'Bengaluru Indie Wave Festival',
      date: '2026-12-05',
      time: '18:30:00',
      type: 'Indie Rock',
      city: 'Bengaluru',
      region: 'Southern Zone',
      event_desc: 'A vibrant evening with breakthrough Indian indie rock bands, Hindi acoustic ballads, and live guitars.',
      status: 'Scheduled',
      total_attendees: 0,
      category: 'Tour Stop',
      ssn: 'GST-BLR-8829',
      parent_concert_id: null
    }
  ],
  performs_at: [
    { concert_id: 1, venue_id: 4, set_list: '1. Mumbai Anthem / 2. Goa Sunset Bass / 3. Dhol Drops / 4. Laser Climax', duration: 240 },
    { concert_id: 2, venue_id: 4, set_list: '1. Raga Bhairavi Ambient / 2. Acoustic Chords / 3. Sunrise Meditation', duration: 90 },
    { concert_id: 3, venue_id: 3, set_list: '1. Raga Yaman Symphony / 2. Sarod & Violin Duet / 3. Cosmos Crescendo', duration: 150 },
    { concert_id: 4, venue_id: 2, set_list: '1. Dil Mere Anthem / 2. Bangalore Rains / 3. Raaste / 4. Encore Finale', duration: 120 }
  ],
  artists: [
    { artist_id: 1, artist_name: 'Nucleya Live', artist_history: 'Pioneering Indian bass music producer and electronic festival headliner with multiple gold records.', rider_status: 'Approved' },
    { artist_id: 2, artist_name: 'Prateek Kuhad Ensemble', artist_history: 'Critically acclaimed singer-songwriter known for acoustic folk and melodic Hindi-English ballads.', rider_status: 'Approved' },
    { artist_id: 3, artist_name: 'Maestro Vance & The Delhi Philharmonic', artist_history: 'Acclaimed 50-piece fusion orchestra harmonizing Indian sitar, tabla, and western symphonic strings.', rider_status: 'Approved' },
    { artist_id: 4, artist_name: 'The Local Train Collective', artist_history: 'High-energy Hindi indie-rock quartet celebrated for stadium rock anthems and driving rhythms.', rider_status: 'Approved' }
  ],
  artist_bookings: [
    { booking_id: 1, concert_id: 1, artist_id: 1, fee: 450000.00, booking_status: 'Confirmed', performance_slot: '21:00:00' },
    { booking_id: 2, concert_id: 1, artist_id: 2, fee: 220000.00, booking_status: 'Confirmed', performance_slot: '19:00:00' },
    { booking_id: 3, concert_id: 2, artist_id: 2, fee: 85000.00,  booking_status: 'Confirmed', performance_slot: '23:45:00' },
    { booking_id: 4, concert_id: 3, artist_id: 3, fee: 350000.00, booking_status: 'Confirmed', performance_slot: '19:30:00' },
    { booking_id: 5, concert_id: 4, artist_id: 4, fee: 180000.00, booking_status: 'Confirmed', performance_slot: '20:30:00' }
  ],
  promotions: [
    { promotion_id: 1, organizer_id: 1, venue_id: 4, concert_id: 1, target_audience: 'College Students 18-30, Electronic Fans', budget: 150000.00, promo_campaign: 'Sunburn Goa Instagram Reels & Campus Blitz' },
    { promotion_id: 2, organizer_id: 3, venue_id: 3, concert_id: 3, target_audience: 'Classical Patrons, Delhi NCR Audiences', budget: 95000.00,  promo_campaign: 'Radio City Ads & Metro Station Billboards' },
    { promotion_id: 3, organizer_id: 2, venue_id: 2, concert_id: 4, target_audience: 'Bengaluru Tech Community, Indie Rock Fans', budget: 60000.00,  promo_campaign: 'Spotify Audio Campaigns & Cafe Posters' }
  ],
  attendees: [
    { attendee_id: 1, full_name: 'Arjun Sharma', email: 'arjun@livesync.in', preferences: 'EDM, VIP Lounge, Front Row Bass', renewal_count: 5 },
    { attendee_id: 2, full_name: 'Ananya Iyer', email: 'ananya.iyer@example.in', preferences: 'Indie Rock, Acoustic Stage, Balcony View', renewal_count: 3 },
    { attendee_id: 3, full_name: 'Rohan Verma', email: 'rohan.verma@example.in', preferences: 'Classical Fusion, Center Acoustic Seating', renewal_count: 2 },
    { attendee_id: 4, full_name: 'Pooja Patel', email: 'pooja.patel@example.in', preferences: 'Electronic, GA Standing Pit', renewal_count: 4 },
    { attendee_id: 5, full_name: 'Kabir Mehta', email: 'kabir.mehta@example.in', preferences: 'Acoustic Chill-out, VIP Concourse', renewal_count: 1 }
  ],
  tickets: [
    { ticket_code: 'SB-VIP-01', concert_id: 1, venue_id: 4, seat_number: 'VIP-Deck-01', price: 8500.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SB-VIP-02', concert_id: 1, venue_id: 4, seat_number: 'VIP-Deck-02', price: 8500.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SB-GA-101', concert_id: 1, venue_id: 4, seat_number: 'GA-Floor-101', price: 2499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SB-GA-102', concert_id: 1, venue_id: 4, seat_number: 'GA-Floor-102', price: 2499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SB-GA-103', concert_id: 1, venue_id: 4, seat_number: 'GA-Floor-103', price: 2499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SBA-01', concert_id: 2, venue_id: 4, seat_number: 'Lounge-Seat-01', price: 1499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'SBA-02', concert_id: 2, venue_id: 4, seat_number: 'Lounge-Seat-02', price: 1499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'DEL-PREM-01', concert_id: 3, venue_id: 3, seat_number: 'Prem-Row1-Seat12', price: 3999.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'DEL-PREM-02', concert_id: 3, venue_id: 3, seat_number: 'Prem-Row1-Seat13', price: 3999.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'BLR-LAWN-01', concert_id: 4, venue_id: 2, seat_number: 'Lawn-Pass-101', price: 1499.00, ticket_status: 'AVAILABLE' },
    { ticket_code: 'BLR-LAWN-02', concert_id: 4, venue_id: 2, seat_number: 'Lawn-Pass-102', price: 1499.00, ticket_status: 'AVAILABLE' }
  ],
  bookings: [
    // Database cleared: All tickets are AVAILABLE with 0 past bookings
  ],
  audit_logs: [
    { log_id: 1, action_type: 'SYSTEM_BOOT', entity_name: 'SYSTEM', record_id: '0', details: 'LiveSync database initialized successfully with Indian Rupee (INR) schema', created_at: new Date() }
  ],
  artist_riders: JSON.parse(JSON.stringify(sampleArtistRiders)),
  stage_sensor_logs: JSON.parse(JSON.stringify(sampleStageSensorLogs))
};

// ============================================================================
// INITIALIZATION ROUTINE
// ============================================================================
async function initDatabases() {
  if (Pool) {
    try {
      pgPool = new Pool({
        connectionString: PG_CONNECTION_STRING,
        connectionTimeoutMillis: 2000
      });
      const client = await pgPool.connect();
      await client.query('SELECT NOW()');
      client.release();
      isPostgresConnected = true;
    } catch (err) {
      isPostgresConnected = false;
    }
  }

  if (MongoClient) {
    try {
      mongoClient = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 2000 });
      await mongoClient.connect();
      mongoDb = mongoClient.db(MONGO_DB_NAME);
      isMongoConnected = true;
    } catch (err) {
      isMongoConnected = false;
    }
  }
}

initDatabases();

// ============================================================================
// AUTHENTICATION & ACCESS CONTROL
// ============================================================================
async function authenticateUser(usernameOrEmail, password) {
  if (isPostgresConnected && pgPool) {
    try {
      const res = await pgPool.query(
        `SELECT user_id, username, email, full_name, role, attendee_id 
         FROM app_user 
         WHERE (username = $1 OR email = $1) AND password_hash = $2;`,
        [usernameOrEmail, password]
      );
      if (res.rows.length > 0) return { success: true, user: res.rows[0] };
      return { success: false, message: 'Invalid credentials. Please verify your username and password.' };
    } catch (err) {
      console.error('Postgres Auth Error:', err);
    }
  }

  const user = memoryStore.app_users.find(
    u => (u.username === usernameOrEmail || u.email === usernameOrEmail) && u.password_hash === password
  );

  if (user) {
    return {
      success: true,
      user: {
        user_id: user.user_id,
        username: user.username,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        attendee_id: user.attendee_id
      }
    };
  }

  return { success: false, message: 'Invalid credentials. Please verify your username and password.' };
}

// User Registration (Creation of new User account)
async function registerUser(userData) {
  const { username, email, password, fullName, preferences } = userData;

  if (isPostgresConnected && pgPool) {
    try {
      // Check existing
      const checkRes = await pgPool.query(
        'SELECT 1 FROM app_user WHERE username = $1 OR email = $2;',
        [username, email]
      );
      if (checkRes.rows.length > 0) {
        return { success: false, message: 'Username or email already exists.' };
      }

      // Create Attendee record first
      const attRes = await pgPool.query(
        `INSERT INTO attendee (full_name, email, preferences, renewal_count)
         VALUES ($1, $2, $3, 0) RETURNING attendee_id;`,
        [fullName, email, preferences || 'General Admission']
      );
      const newAttendeeId = attRes.rows[0].attendee_id;

      // Create App User
      const userRes = await pgPool.query(
        `INSERT INTO app_user (username, email, password_hash, full_name, role, attendee_id)
         VALUES ($1, $2, $3, $4, 'USER', $5) RETURNING user_id, username, email, full_name, role, attendee_id;`,
        [username, email, password, fullName, newAttendeeId]
      );

      return { success: true, user: userRes.rows[0] };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }

  // In-Memory Registration
  const existing = memoryStore.app_users.find(u => u.username === username || u.email === email);
  if (existing) {
    return { success: false, message: 'Username or email already exists.' };
  }

  const newAttendeeId = memoryStore.attendees.length + 1;
  memoryStore.attendees.push({
    attendee_id: newAttendeeId,
    full_name: fullName,
    email: email,
    preferences: preferences || 'General Admission',
    renewal_count: 0
  });

  const newUserId = memoryStore.app_users.length + 1;
  const newUser = {
    user_id: newUserId,
    username: username,
    email: email,
    password_hash: password,
    full_name: fullName,
    role: 'USER',
    attendee_id: newAttendeeId
  };
  memoryStore.app_users.push(newUser);

  return { success: true, user: newUser };
}

// Admin Elevation Requests
async function getAdminRequests() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query('SELECT * FROM admin_request ORDER BY created_at DESC;');
    return res.rows;
  }
  return [...memoryStore.admin_requests].reverse();
}

async function createAdminRequest(data) {
  const { userId, fullName, email, department, employeeCode, reason } = data;
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(
      `INSERT INTO admin_request (user_id, full_name, email, department, employee_code, reason, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'PENDING') RETURNING *;`,
      [userId, fullName, email, department, employeeCode, reason]
    );
    return res.rows[0];
  }

  const newReq = {
    request_id: memoryStore.admin_requests.length + 1,
    user_id: parseInt(userId, 10),
    full_name: fullName,
    email: email,
    department: department,
    employee_code: employeeCode,
    reason: reason,
    status: 'PENDING',
    reviewed_by: null,
    created_at: new Date()
  };
  memoryStore.admin_requests.push(newReq);
  return newReq;
}

async function approveAdminRequest(requestId, reviewerId) {
  const rId = parseInt(requestId, 10);
  const revId = parseInt(reviewerId, 10);

  if (isPostgresConnected && pgPool) {
    const reqRes = await pgPool.query('SELECT user_id FROM admin_request WHERE request_id = $1;', [rId]);
    if (reqRes.rows.length === 0) return { success: false, message: 'Request not found.' };
    const targetUserId = reqRes.rows[0].user_id;

    await pgPool.query(
      `UPDATE admin_request SET status = 'APPROVED', reviewed_by = $1, updated_at = CURRENT_TIMESTAMP WHERE request_id = $2;`,
      [revId, rId]
    );
    await pgPool.query(`UPDATE app_user SET role = 'ADMIN' WHERE user_id = $1;`, [targetUserId]);

    return { success: true, message: 'Admin request approved. User elevated to Administrator role.' };
  }

  const req = memoryStore.admin_requests.find(r => r.request_id === rId);
  if (!req) return { success: false, message: 'Request not found.' };

  req.status = 'APPROVED';
  req.reviewed_by = revId;

  const user = memoryStore.app_users.find(u => u.user_id === req.user_id);
  if (user) user.role = 'ADMIN';

  return { success: true, message: 'Admin request approved. User elevated to Administrator role.' };
}

// ----------------------------------------------------------------------------
// READ OPERATIONS
// ----------------------------------------------------------------------------
async function getConcerts() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(`
      SELECT c.*, v.venue_name, v.max_capacity,
             p.event_title AS parent_event_title
      FROM concert c
      LEFT JOIN performs_at pa ON c.concert_id = pa.concert_id
      LEFT JOIN venue v ON pa.venue_id = v.venue_id
      LEFT JOIN concert p ON c.parent_concert_id = p.concert_id
      ORDER BY c.date ASC, c.time ASC;
    `);
    return res.rows;
  }

  return memoryStore.concerts.map(c => {
    const perf = memoryStore.performs_at.find(p => p.concert_id === c.concert_id);
    const venue = perf ? memoryStore.venues.find(v => v.venue_id === perf.venue_id) : null;
    const parent = c.parent_concert_id ? memoryStore.concerts.find(p => p.concert_id === c.parent_concert_id) : null;
    return {
      ...c,
      venue_name: venue ? venue.venue_name : 'TBD',
      max_capacity: venue ? venue.max_capacity : 0,
      parent_event_title: parent ? parent.event_title : null
    };
  });
}

async function getConcertById(id) {
  const concertId = parseInt(id, 10);
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(`
      SELECT c.*, v.venue_id, v.venue_name, v.max_capacity, pa.set_list, pa.duration
      FROM concert c
      LEFT JOIN performs_at pa ON c.concert_id = pa.concert_id
      LEFT JOIN venue v ON pa.venue_id = v.venue_id
      WHERE c.concert_id = $1;
    `, [concertId]);
    return res.rows[0] || null;
  }

  const c = memoryStore.concerts.find(item => item.concert_id === concertId);
  if (!c) return null;
  const perf = memoryStore.performs_at.find(p => p.concert_id === concertId);
  const venue = perf ? memoryStore.venues.find(v => v.venue_id === perf.venue_id) : null;
  return {
    ...c,
    venue_id: venue ? venue.venue_id : null,
    venue_name: venue ? venue.venue_name : 'TBD',
    max_capacity: venue ? venue.max_capacity : 0,
    set_list: perf ? perf.set_list : null,
    duration: perf ? perf.duration : null
  };
}

// Admin: Create Concert and Venue Card
async function createConcert(data) {
  const {
    event_title,
    date,
    time,
    type,
    city,
    region,
    event_desc,
    venue_id,
    new_venue_name,
    new_venue_capacity,
    new_venue_locations,
    ticket_price,
    ticket_count,
    parent_concert_id
  } = data;

  const basePrice = parseFloat(ticket_price) || 1999.00;
  const numTickets = parseInt(ticket_count, 10) || 12;

  if (isPostgresConnected && pgPool) {
    let resolvedVenueId = parseInt(venue_id, 10);
    // If new venue chosen
    if (!resolvedVenueId || venue_id === 'NEW') {
      const vRes = await pgPool.query(
        `INSERT INTO venue (venue_name, max_capacity, locations, renewal_count)
         VALUES ($1, $2, $3, 1) RETURNING venue_id;`,
        [new_venue_name || `${city} Live Arena`, parseInt(new_venue_capacity, 10) || 10000, new_venue_locations || `${city}, India`]
      );
      resolvedVenueId = vRes.rows[0].venue_id;
    }

    const cRes = await pgPool.query(
      `INSERT INTO concert (event_title, date, time, type, city, region, event_desc, status, total_attendees, category, ssn, parent_concert_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'Scheduled', 0, 'Festival Tour', $8, $9) RETURNING *;`,
      [
        event_title,
        date,
        time || '18:00:00',
        type || 'Music Festival',
        city,
        region || 'Indian Zone',
        event_desc || 'Live stadium experience with high-fidelity acoustics and stagecraft.',
        `GST-${(city || 'IND').toUpperCase().substring(0, 3)}-${Date.now().toString().slice(-4)}`,
        parent_concert_id ? parseInt(parent_concert_id, 10) : null
      ]
    );
    const newConcert = cRes.rows[0];

    // Performs_at link
    await pgPool.query(
      `INSERT INTO performs_at (concert_id, venue_id, set_list, duration)
       VALUES ($1, $2, '1. Live Festival Set / 2. Headliner Showcase / 3. Encore', 150)
       ON CONFLICT DO NOTHING;`,
      [newConcert.concert_id, resolvedVenueId]
    );

    // Generate Tickets
    const prefix = (city || 'IND').toUpperCase().replace(/[^A-Z]/g, '').substring(0, 3) || 'CON';
    for (let i = 1; i <= numTickets; i++) {
      const tCode = `${prefix}-${newConcert.concert_id}-${String(i).padStart(3, '0')}`;
      const seatNum = i <= 3 ? `VIP-Box-${i}` : `Floor-Seat-${i}`;
      const seatPrice = i <= 3 ? basePrice * 2 : basePrice;
      await pgPool.query(
        `INSERT INTO ticket (ticket_code, concert_id, venue_id, seat_number, price, ticket_status)
         VALUES ($1, $2, $3, $4, $5, 'AVAILABLE') ON CONFLICT DO NOTHING;`,
        [tCode, newConcert.concert_id, resolvedVenueId, seatNum, seatPrice]
      );
    }

    // Audit log
    await pgPool.query(
      `INSERT INTO audit_log (action_type, entity_name, record_id, details)
       VALUES ('INSERT', 'CONCERT', $1, $2);`,
      [newConcert.concert_id.toString(), `Admin created new concert "${event_title}" with ${numTickets} available seats.`]
    );

    return { success: true, concert: newConcert };
  }

  // In-Memory fallback store
  let resolvedVenueId = parseInt(venue_id, 10);
  let resolvedVenue = memoryStore.venues.find(v => v.venue_id === resolvedVenueId);

  if (!resolvedVenue || venue_id === 'NEW') {
    resolvedVenueId = memoryStore.venues.length + 1;
    resolvedVenue = {
      venue_id: resolvedVenueId,
      venue_name: new_venue_name || `${city} Live Arena`,
      max_capacity: parseInt(new_venue_capacity, 10) || 10000,
      locations: new_venue_locations || `${city}, India`,
      renewal_count: 1
    };
    memoryStore.venues.push(resolvedVenue);
  }

  const newConcertId = memoryStore.concerts.length + 1;
  const newConcert = {
    concert_id: newConcertId,
    event_title,
    date,
    time: time || '18:00:00',
    type: type || 'Music Festival',
    city,
    region: region || 'Indian Zone',
    event_desc: event_desc || 'Live stadium experience with high-fidelity acoustics and stagecraft.',
    status: 'Scheduled',
    total_attendees: 0,
    category: 'Festival Tour',
    ssn: `GST-${(city || 'IND').toUpperCase().substring(0, 3)}-${Date.now().toString().slice(-4)}`,
    parent_concert_id: parent_concert_id ? parseInt(parent_concert_id, 10) : null
  };
  memoryStore.concerts.push(newConcert);

  // Performs_at link
  memoryStore.performs_at.push({
    concert_id: newConcertId,
    venue_id: resolvedVenueId,
    set_list: '1. Live Festival Set / 2. Headliner Showcase / 3. Encore',
    duration: 150
  });

  // Generate Tickets
  const prefix = (city || 'IND').toUpperCase().replace(/[^A-Z]/g, '').substring(0, 3) || 'CON';
  for (let i = 1; i <= numTickets; i++) {
    const tCode = `${prefix}-${newConcertId}-${String(i).padStart(3, '0')}`;
    const seatNum = i <= 3 ? `VIP-Box-${i}` : `Floor-Seat-${i}`;
    const seatPrice = i <= 3 ? basePrice * 2 : basePrice;
    memoryStore.tickets.push({
      ticket_code: tCode,
      concert_id: newConcertId,
      venue_id: resolvedVenueId,
      seat_number: seatNum,
      price: seatPrice,
      ticket_status: 'AVAILABLE'
    });
  }

  // Audit log
  memoryStore.audit_logs.push({
    log_id: memoryStore.audit_logs.length + 1,
    action_type: 'INSERT',
    entity_name: 'CONCERT',
    record_id: newConcertId.toString(),
    details: `Admin created new concert "${event_title}" at venue "${resolvedVenue.venue_name}" with ${numTickets} available seats.`,
    created_at: new Date()
  });

  return { success: true, concert: newConcert };
}

async function getTicketsForConcert(concertId) {
  const cId = parseInt(concertId, 10);
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(`
      SELECT t.*, c.event_title, v.venue_name
      FROM ticket t
      JOIN concert c ON t.concert_id = c.concert_id
      LEFT JOIN venue v ON t.venue_id = v.venue_id
      WHERE t.concert_id = $1
      ORDER BY t.seat_number ASC;
    `, [cId]);
    return res.rows;
  }

  return memoryStore.tickets
    .filter(t => t.concert_id === cId)
    .map(t => {
      const concert = memoryStore.concerts.find(c => c.concert_id === t.concert_id);
      const venue = memoryStore.venues.find(v => v.venue_id === t.venue_id);
      return {
        ...t,
        event_title: concert ? concert.event_title : '',
        venue_name: venue ? venue.venue_name : ''
      };
    });
}

async function getAttendees() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query('SELECT * FROM attendee ORDER BY attendee_id ASC;');
    return res.rows;
  }
  return memoryStore.attendees;
}

async function getVenues() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query('SELECT * FROM venue ORDER BY venue_id ASC;');
    return res.rows;
  }
  return memoryStore.venues;
}

// ----------------------------------------------------------------------------
// ATOMIC BOOKING TRANSACTION
// ----------------------------------------------------------------------------
async function executeBookTicketTransaction(attendeeId, ticketCode, amount) {
  const attId = parseInt(attendeeId, 10);
  const ticketAmount = parseFloat(amount);

  if (isPostgresConnected && pgPool) {
    const client = await pgPool.connect();
    try {
      await client.query('BEGIN;');
      const ticketRes = await client.query(
        'SELECT ticket_status, price, concert_id, venue_id FROM ticket WHERE ticket_code = $1 FOR UPDATE;',
        [ticketCode]
      );
      if (ticketRes.rows.length === 0) {
        await client.query('ROLLBACK;');
        return { success: false, message: `Ticket ${ticketCode} not found.` };
      }
      const ticket = ticketRes.rows[0];
      if (ticket.ticket_status !== 'AVAILABLE') {
        await client.query('ROLLBACK;');
        return { success: false, message: `Ticket ${ticketCode} is already ${ticket.ticket_status}.` };
      }

      if (ticket.venue_id) {
        const capRes = await client.query('SELECT max_capacity FROM venue WHERE venue_id = $1;', [ticket.venue_id]);
        const maxCap = capRes.rows[0].max_capacity;
        const soldRes = await client.query('SELECT COUNT(*) FROM ticket WHERE concert_id = $1 AND ticket_status = $2;', [ticket.concert_id, 'BOOKED']);
        if (parseInt(soldRes.rows[0].count, 10) >= maxCap) {
          await client.query('ROLLBACK;');
          return { success: false, message: `Venue capacity limit reached for this event.` };
        }
      }

      await client.query("UPDATE ticket SET ticket_status = 'BOOKED' WHERE ticket_code = $1;", [ticketCode]);

      const bookRes = await client.query(
        `INSERT INTO booking (ticket_code, attendee_id, booking_date, payment_status, total_amount)
         VALUES ($1, $2, CURRENT_TIMESTAMP, 'COMPLETED', $3) RETURNING booking_id;`,
        [ticketCode, attId, ticketAmount]
      );
      const bookingId = bookRes.rows[0].booking_id;

      await client.query('UPDATE attendee SET renewal_count = renewal_count + 1 WHERE attendee_id = $1;', [attId]);

      await client.query(
        `INSERT INTO audit_log (action_type, entity_name, record_id, details)
         VALUES ('TICKET_BOOKED', 'BOOKING', $1, $2);`,
        [bookingId.toString(), `Ticket ${ticketCode} booked by Attendee ${attId} for ₹${ticketAmount}`]
      );

      await client.query('COMMIT;');
      return { success: true, bookingId, message: `Ticket confirmed! Booking reference: #${bookingId}` };
    } catch (err) {
      await client.query('ROLLBACK;');
      return { success: false, message: err.message };
    } finally {
      client.release();
    }
  }

  // In-Memory Transaction Engine
  const ticket = memoryStore.tickets.find(t => t.ticket_code === ticketCode);
  if (!ticket) return { success: false, message: `Ticket ${ticketCode} not found.` };
  if (ticket.ticket_status !== 'AVAILABLE') return { success: false, message: `Ticket ${ticketCode} is already ${ticket.ticket_status}.` };

  const attendee = memoryStore.attendees.find(a => a.attendee_id === attId);
  if (!attendee) return { success: false, message: `Attendee ID ${attId} not found.` };

  const venue = memoryStore.venues.find(v => v.venue_id === ticket.venue_id);
  const currentSold = memoryStore.tickets.filter(t => t.concert_id === ticket.concert_id && t.ticket_status === 'BOOKED').length;
  if (venue && currentSold >= venue.max_capacity) {
    return { success: false, message: `Venue capacity limit reached.` };
  }

  ticket.ticket_status = 'BOOKED';
  const newBookingId = memoryStore.bookings.length + 1;
  memoryStore.bookings.push({
    booking_id: newBookingId,
    ticket_code: ticketCode,
    attendee_id: attId,
    booking_date: new Date(),
    payment_status: 'COMPLETED',
    total_amount: ticketAmount
  });

  attendee.renewal_count += 1;

  const concert = memoryStore.concerts.find(c => c.concert_id === ticket.concert_id);
  if (concert) concert.total_attendees += 1;

  memoryStore.audit_logs.push({
    log_id: memoryStore.audit_logs.length + 1,
    action_type: 'TICKET_BOOKED',
    entity_name: 'BOOKING',
    record_id: newBookingId.toString(),
    details: `Ticket ${ticketCode} booked by Attendee ${attId} for ₹${ticketAmount}`,
    created_at: new Date()
  });

  return {
    success: true,
    bookingId: newBookingId,
    message: `Ticket confirmed! Booking reference: #${newBookingId}`
  };
}

// ----------------------------------------------------------------------------
// STORED PROCEDURE: CANCELLATION
// ----------------------------------------------------------------------------
async function executeCancelConcertProcedure(concertId) {
  const cId = parseInt(concertId, 10);

  if (isPostgresConnected && pgPool) {
    try {
      await pgPool.query('CALL cancel_concert_and_refund($1, NULL, NULL);', [cId]);
      return { success: true, message: `Event #${cId} successfully cancelled. All purchased tickets have been marked for refund.` };
    } catch (err) {
      return { success: false, message: err.message };
    }
  }

  const concert = memoryStore.concerts.find(c => c.concert_id === cId);
  if (!concert) return { success: false, message: `Event not found.` };
  if (concert.status === 'Cancelled') return { success: false, message: `Event is already marked as Cancelled.` };

  concert.status = 'Cancelled';
  concert.total_attendees = 0;

  let refundedCount = 0;
  memoryStore.tickets.forEach(t => {
    if (t.concert_id === cId) {
      if (t.ticket_status === 'BOOKED') {
        t.ticket_status = 'REFUNDED';
        refundedCount++;
        const booking = memoryStore.bookings.find(b => b.ticket_code === t.ticket_code);
        if (booking) booking.payment_status = 'REFUNDED';
      } else if (t.ticket_status === 'AVAILABLE') {
        t.ticket_status = 'CANCELLED';
      }
    }
  });

  memoryStore.audit_logs.push({
    log_id: memoryStore.audit_logs.length + 1,
    action_type: 'CONCERT_CANCELLED',
    entity_name: 'CONCERT',
    record_id: cId.toString(),
    details: `Concert "${concert.event_title}" cancelled. ${refundedCount} tickets marked for refund.`,
    created_at: new Date()
  });

  return {
    success: true,
    refundedCount,
    message: `Event "${concert.event_title}" cancelled. ${refundedCount} tickets processed for refund.`
  };
}

// ----------------------------------------------------------------------------
// COMPLEX ANALYTICAL VIEW
// ----------------------------------------------------------------------------
async function getConcertAnalyticsView() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query('SELECT * FROM view_concert_performance_analytics ORDER BY concert_id ASC;');
    return res.rows;
  }

  return memoryStore.concerts.map(c => {
    const perf = memoryStore.performs_at.find(p => p.concert_id === c.concert_id);
    const venue = perf ? memoryStore.venues.find(v => v.venue_id === perf.venue_id) : null;
    const tickets = memoryStore.tickets.filter(t => t.concert_id === c.concert_id);
    const bookedTickets = tickets.filter(t => t.ticket_status === 'BOOKED');
    const availableTickets = tickets.filter(t => t.ticket_status === 'AVAILABLE');

    const maxCapacity = venue ? venue.max_capacity : 0;
    const occupancy = maxCapacity > 0 ? parseFloat(((bookedTickets.length / maxCapacity) * 100).toFixed(2)) : 0;
    const revenue = bookedTickets.reduce((sum, t) => sum + t.price, 0);

    const artistBookings = memoryStore.artist_bookings.filter(ab => ab.concert_id === c.concert_id);
    const artistFees = artistBookings.reduce((sum, ab) => sum + ab.fee, 0);

    const promo = memoryStore.promotions.find(p => p.concert_id === c.concert_id);
    const promoBudget = promo ? promo.budget : 0;

    const netProfit = revenue - (artistFees + promoBudget);

    return {
      concert_id: c.concert_id,
      event_title: c.event_title,
      concert_date: c.date,
      city: c.city,
      concert_status: c.status,
      venue_name: venue ? venue.venue_name : 'TBD',
      max_capacity: maxCapacity,
      total_attendees: c.total_attendees,
      total_tickets_created: tickets.length,
      tickets_sold: bookedTickets.length,
      tickets_available: availableTickets.length,
      occupancy_percentage: occupancy,
      gross_ticket_revenue: revenue,
      total_artist_fees: artistFees,
      promotion_budget: promoBudget,
      net_profit_or_loss: netProfit,
      financial_status: netProfit >= 0 ? 'PROFITABLE' : 'DEFICIT'
    };
  });
}

// User Personal Bookings
async function getUserBookings(attendeeId) {
  const attId = parseInt(attendeeId, 10);
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(`
      SELECT b.booking_id, b.ticket_code, b.booking_date, b.payment_status, b.total_amount,
             t.seat_number, c.event_title, c.date AS concert_date, c.time AS concert_time, c.city, v.venue_name
      FROM booking b
      JOIN ticket t ON b.ticket_code = t.ticket_code
      JOIN concert c ON t.concert_id = c.concert_id
      LEFT JOIN venue v ON t.venue_id = v.venue_id
      WHERE b.attendee_id = $1
      ORDER BY b.booking_date DESC;
    `, [attId]);
    return res.rows;
  }

  return memoryStore.bookings
    .filter(b => b.attendee_id === attId)
    .map(b => {
      const ticket = memoryStore.tickets.find(t => t.ticket_code === b.ticket_code);
      const concert = ticket ? memoryStore.concerts.find(c => c.concert_id === ticket.concert_id) : null;
      const venue = ticket ? memoryStore.venues.find(v => v.venue_id === ticket.venue_id) : null;
      return {
        ...b,
        seat_number: ticket ? ticket.seat_number : '',
        event_title: concert ? concert.event_title : 'Concert',
        concert_date: concert ? concert.date : '',
        concert_time: concert ? concert.time : '',
        city: concert ? concert.city : '',
        venue_name: venue ? venue.venue_name : ''
      };
    });
}

// All Bookings for Admin
async function getAllBookings() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query(`
      SELECT b.booking_id, b.ticket_code, b.booking_date, b.payment_status, b.total_amount,
             a.full_name AS attendee_name, a.email AS attendee_email,
             t.seat_number, c.event_title, c.city, v.venue_name
      FROM booking b
      JOIN attendee a ON b.attendee_id = a.attendee_id
      JOIN ticket t ON b.ticket_code = t.ticket_code
      JOIN concert c ON t.concert_id = c.concert_id
      LEFT JOIN venue v ON t.venue_id = v.venue_id
      ORDER BY b.booking_date DESC;
    `);
    return res.rows;
  }

  return [...memoryStore.bookings].reverse().map(b => {
    const attendee = memoryStore.attendees.find(a => a.attendee_id === b.attendee_id);
    const ticket = memoryStore.tickets.find(t => t.ticket_code === b.ticket_code);
    const concert = ticket ? memoryStore.concerts.find(c => c.concert_id === ticket.concert_id) : null;
    const venue = ticket ? memoryStore.venues.find(v => v.venue_id === ticket.venue_id) : null;
    return {
      ...b,
      attendee_name: attendee ? attendee.full_name : 'Guest',
      attendee_email: attendee ? attendee.email : '',
      seat_number: ticket ? ticket.seat_number : '',
      event_title: concert ? concert.event_title : '',
      city: concert ? concert.city : '',
      venue_name: venue ? venue.venue_name : ''
    };
  });
}

// ----------------------------------------------------------------------------
// NOSQL DATA ACCESS
// ----------------------------------------------------------------------------
async function getArtistRiders() {
  if (isMongoConnected && mongoDb) {
    return await mongoDb.collection('artist_riders').find({}).toArray();
  }
  return memoryStore.artist_riders;
}

async function getArtistRiderById(artistId) {
  const aId = parseInt(artistId, 10);
  if (isMongoConnected && mongoDb) {
    return await mongoDb.collection('artist_riders').findOne({ artist_id: aId });
  }
  return memoryStore.artist_riders.find(r => r.artist_id === aId) || null;
}

// Admin: Create Artist Rider Card
async function createArtistRider(data) {
  const {
    artist_name,
    genre,
    approval_status,
    audio_channels,
    stage_dimensions,
    monitoring_type,
    gear_specs,
    dressing_rooms,
    room_temp,
    catering
  } = data;

  const newArtistId = memoryStore.artist_riders.length + 1;

  let gearList = [];
  if (Array.isArray(gear_specs)) {
    gearList = gear_specs;
  } else if (typeof gear_specs === 'string' && gear_specs.trim().length > 0) {
    gearList = gear_specs.split(/[,;\n]+/).map(item => {
      const trimmed = item.trim();
      const match = trimmed.match(/^(\d+)x?\s*(.+)$/i);
      if (match) {
        return { item: match[2], qty: parseInt(match[1], 10) || 1, notes: 'Stage requirement' };
      }
      return { item: trimmed, qty: 1, notes: 'Stage requirement' };
    });
  } else {
    gearList = [
      { item: 'Digital Stage Console & Mics', qty: 1, notes: 'Main vocal & instrument rig' },
      { item: 'Stereo Wireless IEM Mixes', qty: 2, notes: 'Pre-calibrated' }
    ];
  }

  let beverageList = [];
  if (Array.isArray(catering)) {
    beverageList = catering;
  } else if (typeof catering === 'string' && catering.trim().length > 0) {
    beverageList = catering.split(/[,;\n]+/).map(s => s.trim()).filter(Boolean);
  } else {
    beverageList = ['Fresh Tender Coconut Water', 'Mineral Water (12 bottles)', 'Herbal Tea'];
  }

  const riderDoc = {
    artist_id: newArtistId,
    artist_name: artist_name || 'Featured Artist',
    genre: genre || 'Live Music',
    technical_rider: {
      audio_channels: parseInt(audio_channels, 10) || 16,
      stage_dimensions: stage_dimensions || '14m x 9m elevated stage',
      gear_specs: gearList,
      monitoring_type: monitoring_type || 'Custom In-Ear Monitoring & Wedges',
      lighting_cues: ['Main stage spotlight', 'Atmospheric haze']
    },
    hospitality_rider: {
      dressing_rooms: parseInt(dressing_rooms, 10) || 1,
      dietary_restrictions: ['Organic Vegetarian Options'],
      beverages: beverageList,
      room_temperature_celsius: parseFloat(room_temp) || 21.0
    },
    approval_status: approval_status || 'Approved',
    last_updated: new Date()
  };

  if (isMongoConnected && mongoDb) {
    try {
      await mongoDb.collection('artist_riders').insertOne(riderDoc);
    } catch (err) {
      console.error('MongoDB Insert Rider error:', err);
    }
  }

  memoryStore.artist_riders.push(riderDoc);

  memoryStore.audit_logs.push({
    log_id: memoryStore.audit_logs.length + 1,
    action_type: 'INSERT',
    entity_name: 'ARTIST_RIDER',
    record_id: newArtistId.toString(),
    details: `Admin registered new artist technical rider for "${riderDoc.artist_name}".`,
    created_at: new Date()
  });

  return { success: true, rider: riderDoc };
}

async function getStageSensorLogs(concertId) {
  const cId = concertId ? parseInt(concertId, 10) : null;
  if (isMongoConnected && mongoDb) {
    const filter = cId ? { concert_id: cId } : {};
    return await mongoDb.collection('stage_sensor_logs').find(filter).sort({ timestamp: -1 }).limit(20).toArray();
  }
  let logs = memoryStore.stage_sensor_logs;
  if (cId) logs = logs.filter(l => l.concert_id === cId);
  return logs.slice(-20).reverse();
}

async function insertStageSensorLog(sensorData) {
  const newLog = {
    ...sensorData,
    timestamp: new Date()
  };
  if (isMongoConnected && mongoDb) {
    const res = await mongoDb.collection('stage_sensor_logs').insertOne(newLog);
    return { ...newLog, _id: res.insertedId };
  }
  memoryStore.stage_sensor_logs.push(newLog);
  return newLog;
}

async function getAuditLogs() {
  if (isPostgresConnected && pgPool) {
    const res = await pgPool.query('SELECT * FROM audit_log ORDER BY created_at DESC LIMIT 25;');
    return res.rows;
  }
  return [...memoryStore.audit_logs].reverse();
}

module.exports = {
  authenticateUser,
  registerUser,
  getAdminRequests,
  createAdminRequest,
  approveAdminRequest,
  getConcerts,
  getConcertById,
  createConcert,
  getTicketsForConcert,
  getAttendees,
  getVenues,
  executeBookTicketTransaction,
  executeCancelConcertProcedure,
  getConcertAnalyticsView,
  getUserBookings,
  getAllBookings,
  getArtistRiders,
  getArtistRiderById,
  createArtistRider,
  getStageSensorLogs,
  insertStageSensorLog,
  getAuditLogs
};
