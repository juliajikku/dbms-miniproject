/**
 * LiveSync: Concert & Event Management System
 * Database Schema and Seed Initialization Script
 * File: database/init_db.js
 * Run via: node database/init_db.js
 */

const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const { MongoClient } = require('mongodb');
const { artistRiderValidator, stageSensorLogValidator, sampleArtistRiders, sampleStageSensorLogs } = require('./nosql_schema');

const PG_URL = process.env.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/livesync_db';
const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017';
const MONGO_DB_NAME = process.env.MONGO_DB_NAME || 'livesync_nosql';

async function init() {
  console.log('================================================================');
  console.log(' LiveSync: Initializing SQL (PostgreSQL) and NoSQL (MongoDB)');
  console.log('================================================================');

  // 1. PostgreSQL Initialization
  try {
    console.log(`Connecting to PostgreSQL at: ${PG_URL}...`);
    const pool = new Pool({ connectionString: PG_URL, connectionTimeoutMillis: 3000 });
    const client = await pool.connect();
    console.log(' Connected to PostgreSQL. Applying schema.sql...');

    const schemaSql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf-8');
    await client.query(schemaSql);
    console.log(' schema.sql successfully executed (Tables, Constraints, Triggers, Procedures, Views).');

    console.log(' Applying seed.sql...');
    const seedSql = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf-8');
    await client.query(seedSql);
    console.log(' seed.sql successfully executed (Sample data populated).');

    client.release();
    await pool.end();
  } catch (err) {
    console.warn(`! Note on PostgreSQL: ${err.message}`);
    console.warn('  (If you do not have PostgreSQL running locally, the LiveSync web app will automatically');
    console.warn('   use its built-in in-memory DBMS engine so you can evaluate everything immediately.)\n');
  }

  // 2. MongoDB Initialization
  try {
    console.log(`Connecting to MongoDB at: ${MONGO_URI}...`);
    const mongo = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 3000 });
    await mongo.connect();
    const db = mongo.db(MONGO_DB_NAME);
    console.log(` Connected to MongoDB (${MONGO_DB_NAME}). Initializing collections...`);

    // Reset collections
    const collections = await db.listCollections().toArray();
    const colNames = collections.map(c => c.name);

    if (colNames.includes('artist_riders')) await db.collection('artist_riders').drop();
    if (colNames.includes('stage_sensor_logs')) await db.collection('stage_sensor_logs').drop();

    await db.createCollection('artist_riders', { validator: artistRiderValidator });
    await db.createCollection('stage_sensor_logs', { validator: stageSensorLogValidator });

    // Populate collections
    await db.collection('artist_riders').insertMany(sampleArtistRiders);
    await db.collection('stage_sensor_logs').insertMany(sampleStageSensorLogs);

    // Create Indexes
    await db.collection('artist_riders').createIndex({ artist_id: 1 }, { unique: true });
    await db.collection('stage_sensor_logs').createIndex({ concert_id: 1, timestamp: -1 });

    console.log(' MongoDB collections "artist_riders" and "stage_sensor_logs" initialized.');
    await mongo.close();
  } catch (err) {
    console.warn(`! Note on MongoDB: ${err.message}`);
    console.warn('  (If MongoDB is not running locally, the LiveSync web app will seamlessly');
    console.warn('   emulate the NoSQL collections in-memory with the same schema and sample documents.)\n');
  }

  console.log('Database initialization check complete. You can now run "npm start".\n');
}

init();
