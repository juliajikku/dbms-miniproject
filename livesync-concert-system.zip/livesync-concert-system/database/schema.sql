-- ============================================================================
-- LiveSync India: Concert & Event Management System
-- Production-Grade Relational Schema (PostgreSQL)
-- File: database/schema.sql
-- ============================================================================

-- Drop existing tables, views, procedures, and triggers if they exist
DROP VIEW IF EXISTS view_concert_performance_analytics CASCADE;
DROP VIEW IF EXISTS view_attendee_booking_summary CASCADE;
DROP TABLE IF EXISTS gear_booking CASCADE;
DROP TABLE IF EXISTS booking CASCADE;
DROP TABLE IF EXISTS ticket CASCADE;
DROP TABLE IF EXISTS admin_request CASCADE;
DROP TABLE IF EXISTS app_user CASCADE;
DROP TABLE IF EXISTS attendee CASCADE;
DROP TABLE IF EXISTS works_on_stage CASCADE;
DROP TABLE IF EXISTS production_gear CASCADE;
DROP TABLE IF EXISTS promotion CASCADE;
DROP TABLE IF EXISTS artist_booking CASCADE;
DROP TABLE IF EXISTS artist CASCADE;
DROP TABLE IF EXISTS performs_at CASCADE;
DROP TABLE IF EXISTS venue_locations CASCADE;
DROP TABLE IF EXISTS concert CASCADE;
DROP TABLE IF EXISTS venue CASCADE;
DROP TABLE IF EXISTS organizer CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;

-- ============================================================================
-- 1. CORE ENTITY TABLES & CONSTRAINTS
-- ============================================================================

-- Audit log table for recording transaction events and procedure executions
CREATE TABLE audit_log (
    log_id SERIAL PRIMARY KEY,
    action_type VARCHAR(50) NOT NULL,
    entity_name VARCHAR(50) NOT NULL,
    record_id VARCHAR(100),
    details TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table: VENUE
-- Represents physical stadiums, arenas, and grounds across India
CREATE TABLE venue (
    venue_id SERIAL PRIMARY KEY,
    venue_name VARCHAR(150) NOT NULL,
    max_capacity INT NOT NULL CHECK (max_capacity > 0),
    locations VARCHAR(255) NOT NULL,
    renewal_count INT DEFAULT 0 CHECK (renewal_count >= 0)
);

-- Multivalued attribute mapping for Venue Locations (Gate / Zone / Coordinates)
CREATE TABLE venue_locations (
    venue_id INT NOT NULL REFERENCES venue(venue_id) ON DELETE CASCADE,
    location_detail VARCHAR(150) NOT NULL,
    PRIMARY KEY (venue_id, location_detail)
);

-- Table: ORGANIZER
-- Represents event promoters, stage coordinators, and production companies
CREATE TABLE organizer (
    organizer_id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    location VARCHAR(200) NOT NULL
);

-- Table: CONCERT
-- Central event entity with recursive unary relationship (SUB_EVENTS)
CREATE TABLE concert (
    concert_id SERIAL PRIMARY KEY,
    event_title VARCHAR(200) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    type VARCHAR(50) NOT NULL DEFAULT 'Music Festival',
    city VARCHAR(100) NOT NULL,
    region VARCHAR(100) NOT NULL,
    event_desc TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'Scheduled' 
        CHECK (status IN ('Scheduled', 'In Progress', 'Completed', 'Cancelled', 'Postponed')),
    total_attendees INT DEFAULT 0 CHECK (total_attendees >= 0),
    category VARCHAR(50) DEFAULT 'Main Stage',
    ssn VARCHAR(50), -- Registration / GST permit code
    -- Recursive unary relationship: Parent (1) to Mentee/Sub-events (N)
    parent_concert_id INT REFERENCES concert(concert_id) ON DELETE SET NULL
);

-- Relationship Table: PERFORMS_AT
-- M:N relationship between CONCERT and VENUE with relationship attributes
CREATE TABLE performs_at (
    concert_id INT NOT NULL REFERENCES concert(concert_id) ON DELETE CASCADE,
    venue_id INT NOT NULL REFERENCES venue(venue_id) ON DELETE CASCADE,
    set_list TEXT,
    duration INT NOT NULL CHECK (duration > 0), -- in minutes
    PRIMARY KEY (concert_id, venue_id)
);

-- Table: ARTIST
-- Weak entity in ER diagram representing the performer and their rider status
CREATE TABLE artist (
    artist_id SERIAL PRIMARY KEY,
    artist_name VARCHAR(150) NOT NULL,
    artist_history TEXT,
    rider_status VARCHAR(50) NOT NULL DEFAULT 'Pending' 
        CHECK (rider_status IN ('Pending', 'Approved', 'Rejected', 'Revised'))
);

-- Table: ARTIST_BOOKING
-- Linking entity between CONCERT and ARTIST with contractual booking fees (in INR ₹)
CREATE TABLE artist_booking (
    booking_id SERIAL PRIMARY KEY,
    concert_id INT NOT NULL REFERENCES concert(concert_id) ON DELETE CASCADE,
    artist_id INT NOT NULL REFERENCES artist(artist_id) ON DELETE CASCADE,
    fee NUMERIC(12, 2) NOT NULL CHECK (fee >= 0),
    booking_status VARCHAR(50) DEFAULT 'Confirmed' 
        CHECK (booking_status IN ('Confirmed', 'Tentative', 'Cancelled')),
    performance_slot TIME,
    UNIQUE (concert_id, artist_id)
);

-- Table: PROMOTION
-- Managed by ORGANIZER for event publicity campaigns (budget in INR ₹)
CREATE TABLE promotion (
    promotion_id SERIAL PRIMARY KEY,
    organizer_id INT NOT NULL REFERENCES organizer(organizer_id) ON DELETE CASCADE,
    venue_id INT REFERENCES venue(venue_id) ON DELETE SET NULL,
    concert_id INT REFERENCES concert(concert_id) ON DELETE CASCADE,
    target_audience VARCHAR(150) NOT NULL,
    budget NUMERIC(12, 2) NOT NULL CHECK (budget >= 0),
    promo_campaign VARCHAR(200) NOT NULL
);

-- Table: PRODUCTION_GEAR
-- Stage equipment managed by ORGANIZER (audio, lighting, pyrotechnics)
CREATE TABLE production_gear (
    gear_id SERIAL PRIMARY KEY,
    organizer_id INT NOT NULL REFERENCES organizer(organizer_id) ON DELETE CASCADE,
    gear_name VARCHAR(150) NOT NULL,
    gear_type VARCHAR(100) NOT NULL,
    quantity INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    condition VARCHAR(50) DEFAULT 'Operational'
);

-- Relationship Table: WORKS_ON_STAGE
-- M:N relationship linking ORGANIZER crew to CONCERT staging
CREATE TABLE works_on_stage (
    concert_id INT NOT NULL REFERENCES concert(concert_id) ON DELETE CASCADE,
    organizer_id INT NOT NULL REFERENCES organizer(organizer_id) ON DELETE CASCADE,
    stage_role VARCHAR(100) DEFAULT 'Stage Coordinator',
    PRIMARY KEY (concert_id, organizer_id)
);

-- Table: ATTENDEE
-- Represents registered concert attendees and buyers
CREATE TABLE attendee (
    attendee_id SERIAL PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    preferences TEXT,
    renewal_count INT DEFAULT 0 CHECK (renewal_count >= 0)
);

-- Table: APP_USER (Authentication & Access Control)
-- Provides authentication for Admin and Regular User accounts
CREATE TABLE app_user (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(100) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER' CHECK (role IN ('ADMIN', 'USER')),
    attendee_id INT REFERENCES attendee(attendee_id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Table: ADMIN_REQUEST (Administrative Approval Workflow)
-- Tracks elevation requests submitted by users wishing to become administrators
CREATE TABLE admin_request (
    request_id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES app_user(user_id) ON DELETE CASCADE,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    department VARCHAR(100) NOT NULL,
    employee_code VARCHAR(50) NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
    reviewed_by INT REFERENCES app_user(user_id) ON DELETE SET NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: TICKET
-- Tickets generated for concerts with individual seat numbers and pricing (in INR ₹)
CREATE TABLE ticket (
    ticket_code VARCHAR(50) PRIMARY KEY,
    concert_id INT NOT NULL REFERENCES concert(concert_id) ON DELETE CASCADE,
    venue_id INT REFERENCES venue(venue_id) ON DELETE SET NULL,
    seat_number VARCHAR(50) NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    ticket_status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE' 
        CHECK (ticket_status IN ('AVAILABLE', 'BOOKED', 'RESERVED', 'CANCELLED', 'REFUNDED')),
    UNIQUE (concert_id, seat_number)
);

-- Table: BOOKING
-- Represents ticket purchases; strictly 1:1 with TICKET as defined in ER diagram
CREATE TABLE booking (
    booking_id SERIAL PRIMARY KEY,
    ticket_code VARCHAR(50) NOT NULL UNIQUE REFERENCES ticket(ticket_code) ON DELETE CASCADE,
    attendee_id INT NOT NULL REFERENCES attendee(attendee_id) ON DELETE CASCADE,
    booking_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    payment_status VARCHAR(50) NOT NULL DEFAULT 'COMPLETED' 
        CHECK (payment_status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED')),
    total_amount NUMERIC(10, 2) NOT NULL CHECK (total_amount >= 0)
);

-- Table: GEAR_BOOKING (BOOKED_BY)
-- Gear checkout / staging assignment connected to attendees or organizers
CREATE TABLE gear_booking (
    gear_booking_id SERIAL PRIMARY KEY,
    gear_id INT NOT NULL REFERENCES production_gear(gear_id) ON DELETE CASCADE,
    attendee_id INT REFERENCES attendee(attendee_id) ON DELETE SET NULL,
    booking_purpose VARCHAR(150) NOT NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create performance indexes for common join operations and lookups
CREATE INDEX idx_concert_date ON concert(date);
CREATE INDEX idx_ticket_concert ON ticket(concert_id);
CREATE INDEX idx_ticket_status ON ticket(ticket_status);
CREATE INDEX idx_booking_attendee ON booking(attendee_id);
CREATE INDEX idx_app_user_email ON app_user(email);
CREATE INDEX idx_admin_request_status ON admin_request(status);


-- ============================================================================
-- 2. ADVANCED SQL PROCEDURES, TRIGGERS & VIEWS
-- ============================================================================

-- ----------------------------------------------------------------------------
-- PROCEDURE 1: book_ticket_transaction (ACID Atomic Concurrency Control)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE book_ticket_transaction(
    p_attendee_id INT,
    p_ticket_code VARCHAR,
    p_amount NUMERIC,
    INOUT p_booking_id INT DEFAULT NULL,
    INOUT p_status_message VARCHAR DEFAULT ''
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_ticket_status VARCHAR(50);
    v_ticket_price NUMERIC(10, 2);
    v_concert_id INT;
    v_venue_id INT;
    v_max_capacity INT;
    v_current_sold INT;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM attendee WHERE attendee_id = p_attendee_id) THEN
        p_status_message := 'FAILED: Attendee ID ' || p_attendee_id || ' does not exist.';
        RETURN;
    END IF;

    -- Concurrency row lock
    SELECT ticket_status, price, concert_id, venue_id
    INTO v_ticket_status, v_ticket_price, v_concert_id, v_venue_id
    FROM ticket
    WHERE ticket_code = p_ticket_code
    FOR UPDATE;

    IF NOT FOUND THEN
        p_status_message := 'FAILED: Ticket ' || p_ticket_code || ' not found.';
        RETURN;
    END IF;

    IF v_ticket_status <> 'AVAILABLE' THEN
        p_status_message := 'FAILED: Ticket ' || p_ticket_code || ' is already ' || v_ticket_status || '.';
        RETURN;
    END IF;

    IF v_venue_id IS NOT NULL THEN
        SELECT max_capacity INTO v_max_capacity FROM venue WHERE venue_id = v_venue_id;
        SELECT COUNT(*) INTO v_current_sold 
        FROM ticket 
        WHERE concert_id = v_concert_id AND ticket_status = 'BOOKED';

        IF v_current_sold >= v_max_capacity THEN
            p_status_message := 'FAILED: Venue capacity of ' || v_max_capacity || ' seats reached.';
            RETURN;
        END IF;
    END IF;

    UPDATE ticket
    SET ticket_status = 'BOOKED'
    WHERE ticket_code = p_ticket_code;

    INSERT INTO booking (ticket_code, attendee_id, booking_date, payment_status, total_amount)
    VALUES (p_ticket_code, p_attendee_id, CURRENT_TIMESTAMP, 'COMPLETED', p_amount)
    RETURNING booking_id INTO p_booking_id;

    UPDATE attendee
    SET renewal_count = renewal_count + 1
    WHERE attendee_id = p_attendee_id;

    INSERT INTO audit_log (action_type, entity_name, record_id, details)
    VALUES ('TICKET_BOOKED', 'BOOKING', p_booking_id::TEXT, 
            'Ticket ' || p_ticket_code || ' booked by Attendee ' || p_attendee_id || ' for INR ' || p_amount);

    p_status_message := 'SUCCESS: Ticket ' || p_ticket_code || ' booked successfully. Booking ID: ' || p_booking_id;
    COMMIT;
END;
$$;


-- ----------------------------------------------------------------------------
-- PROCEDURE 2: cancel_concert_and_refund (Administrative Cascading Refund)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE cancel_concert_and_refund(
    p_concert_id INT,
    INOUT p_tickets_refunded INT DEFAULT 0,
    INOUT p_result_message VARCHAR DEFAULT ''
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_concert_title VARCHAR(200);
    v_current_status VARCHAR(50);
BEGIN
    SELECT event_title, status INTO v_concert_title, v_current_status
    FROM concert
    WHERE concert_id = p_concert_id;

    IF NOT FOUND THEN
        p_result_message := 'FAILED: Concert ID ' || p_concert_id || ' does not exist.';
        RETURN;
    END IF;

    IF v_current_status = 'Cancelled' THEN
        p_result_message := 'NOTICE: Concert "' || v_concert_title || '" is already marked as Cancelled.';
        RETURN;
    END IF;

    UPDATE concert
    SET status = 'Cancelled',
        total_attendees = 0
    WHERE concert_id = p_concert_id;

    UPDATE booking
    SET payment_status = 'REFUNDED'
    WHERE ticket_code IN (SELECT ticket_code FROM ticket WHERE concert_id = p_concert_id);

    WITH updated_tickets AS (
        UPDATE ticket
        SET ticket_status = 'REFUNDED'
        WHERE concert_id = p_concert_id AND ticket_status = 'BOOKED'
        RETURNING ticket_code
    )
    SELECT COUNT(*) INTO p_tickets_refunded FROM updated_tickets;

    UPDATE ticket
    SET ticket_status = 'CANCELLED'
    WHERE concert_id = p_concert_id AND ticket_status = 'AVAILABLE';

    INSERT INTO audit_log (action_type, entity_name, record_id, details)
    VALUES ('CONCERT_CANCELLED', 'CONCERT', p_concert_id::TEXT, 
            'Concert "' || v_concert_title || '" cancelled. Total refunded tickets: ' || p_tickets_refunded);

    p_result_message := 'SUCCESS: Concert "' || v_concert_title || '" cancelled. ' || p_tickets_refunded || ' tickets refunded.';
    COMMIT;
END;
$$;


-- ----------------------------------------------------------------------------
-- TRIGGERS: Derived Attendance Recalculation & Venue Capacity Check
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_sync_concert_total_attendees()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_concert_id INT;
    v_attendee_count INT;
BEGIN
    IF TG_OP = 'DELETE' THEN
        SELECT concert_id INTO v_concert_id FROM ticket WHERE ticket_code = OLD.ticket_code;
    ELSE
        SELECT concert_id INTO v_concert_id FROM ticket WHERE ticket_code = NEW.ticket_code;
    END IF;

    IF v_concert_id IS NOT NULL THEN
        SELECT COUNT(b.booking_id) INTO v_attendee_count
        FROM booking b
        JOIN ticket t ON b.ticket_code = t.ticket_code
        WHERE t.concert_id = v_concert_id 
          AND b.payment_status = 'COMPLETED' 
          AND t.ticket_status = 'BOOKED';

        UPDATE concert
        SET total_attendees = v_attendee_count
        WHERE concert_id = v_concert_id;
    END IF;

    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_booking_sync_attendees ON booking;
CREATE TRIGGER trg_booking_sync_attendees
AFTER INSERT OR UPDATE OR DELETE ON booking
FOR EACH ROW
EXECUTE FUNCTION fn_sync_concert_total_attendees();


CREATE OR REPLACE FUNCTION fn_enforce_venue_capacity_check()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_max_cap INT;
    v_current_booked INT;
BEGIN
    IF NEW.ticket_status = 'BOOKED' AND (OLD.ticket_status IS DISTINCT FROM 'BOOKED') THEN
        IF NEW.venue_id IS NOT NULL THEN
            SELECT max_capacity INTO v_max_cap 
            FROM venue 
            WHERE venue_id = NEW.venue_id;

            SELECT COUNT(*) INTO v_current_booked
            FROM ticket
            WHERE concert_id = NEW.concert_id AND ticket_status = 'BOOKED';

            IF v_current_booked >= v_max_cap THEN
                RAISE EXCEPTION 'Cannot book ticket %: Venue capacity of % seats exceeded for concert %.',
                    NEW.ticket_code, v_max_cap, NEW.concert_id;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_capacity ON ticket;
CREATE TRIGGER trg_enforce_capacity
BEFORE UPDATE OF ticket_status ON ticket
FOR EACH ROW
EXECUTE FUNCTION fn_enforce_venue_capacity_check();


-- ----------------------------------------------------------------------------
-- COMPLEX VIEW: Concert Financial & Attendance Analytics (in INR ₹)
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW view_concert_performance_analytics AS
SELECT 
    c.concert_id,
    c.event_title,
    c.date AS concert_date,
    c.city,
    c.status AS concert_status,
    v.venue_name,
    v.max_capacity,
    c.total_attendees,
    
    COUNT(t.ticket_code) AS total_tickets_created,
    COUNT(CASE WHEN t.ticket_status = 'BOOKED' THEN 1 END) AS tickets_sold,
    COUNT(CASE WHEN t.ticket_status = 'AVAILABLE' THEN 1 END) AS tickets_available,
    
    CASE 
        WHEN v.max_capacity > 0 THEN 
            ROUND((COUNT(CASE WHEN t.ticket_status = 'BOOKED' THEN 1 END)::NUMERIC / v.max_capacity::NUMERIC) * 100, 2)
        ELSE 0 
    END AS occupancy_percentage,

    COALESCE(SUM(CASE WHEN t.ticket_status = 'BOOKED' THEN b.total_amount ELSE 0 END), 0) AS gross_ticket_revenue,
    COALESCE(ab.total_artist_fees, 0) AS total_artist_fees,
    COALESCE(p.budget, 0) AS promotion_budget,
    
    (COALESCE(SUM(CASE WHEN t.ticket_status = 'BOOKED' THEN b.total_amount ELSE 0 END), 0) 
     - (COALESCE(ab.total_artist_fees, 0) + COALESCE(p.budget, 0))) AS net_profit_or_loss,

    CASE 
        WHEN (COALESCE(SUM(CASE WHEN t.ticket_status = 'BOOKED' THEN b.total_amount ELSE 0 END), 0) 
              - (COALESCE(ab.total_artist_fees, 0) + COALESCE(p.budget, 0))) >= 0 
        THEN 'PROFITABLE'
        ELSE 'DEFICIT'
    END AS financial_status

FROM concert c
LEFT JOIN performs_at pa ON c.concert_id = pa.concert_id
LEFT JOIN venue v ON pa.venue_id = v.venue_id
LEFT JOIN ticket t ON c.concert_id = t.concert_id
LEFT JOIN booking b ON t.ticket_code = b.ticket_code AND b.payment_status = 'COMPLETED'
LEFT JOIN (
    SELECT concert_id, SUM(fee) AS total_artist_fees 
    FROM artist_booking 
    GROUP BY concert_id
) ab ON c.concert_id = ab.concert_id
LEFT JOIN promotion p ON c.concert_id = p.concert_id
GROUP BY 
    c.concert_id, c.event_title, c.date, c.city, c.status, 
    v.venue_name, v.max_capacity, c.total_attendees, ab.total_artist_fees, p.budget;


CREATE OR REPLACE VIEW view_attendee_booking_summary AS
SELECT 
    a.attendee_id,
    a.full_name,
    a.email,
    a.preferences,
    a.renewal_count,
    COUNT(b.booking_id) AS total_bookings_made,
    COALESCE(SUM(b.total_amount), 0) AS total_lifetime_spent,
    MAX(b.booking_date) AS last_booking_date
FROM attendee a
LEFT JOIN booking b ON a.attendee_id = b.attendee_id AND b.payment_status = 'COMPLETED'
GROUP BY a.attendee_id, a.full_name, a.email, a.preferences, a.renewal_count;
