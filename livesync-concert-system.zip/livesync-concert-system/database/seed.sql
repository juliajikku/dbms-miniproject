-- ============================================================================
-- LiveSync India: Concert & Event Management System
-- Database Seed Script (PostgreSQL)
-- File: database/seed.sql
-- ============================================================================

TRUNCATE TABLE audit_log, gear_booking, booking, ticket, admin_request, app_user, attendee, works_on_stage, 
               production_gear, promotion, artist_booking, artist, performs_at, 
               venue_locations, concert, venue, organizer RESTART IDENTITY CASCADE;

-- ----------------------------------------------------------------------------
-- 1. SEED VENUES
-- ----------------------------------------------------------------------------
INSERT INTO venue (venue_id, venue_name, max_capacity, locations, renewal_count) VALUES
(1, 'D.Y. Patil Stadium', 55000, 'Sector 7, Nerul, Navi Mumbai, Maharashtra', 5),
(2, 'Palace Grounds Arena', 25000, 'Bellary Road, Jayamahal, Bengaluru, Karnataka', 4),
(3, 'Indira Gandhi Indoor Stadium', 14000, 'Indraprastha Estate, ITO, New Delhi, Delhi', 3),
(4, 'HillTop Vagator Open-Air', 6000, 'Ozran Beach Road, Vagator, Goa', 2);

INSERT INTO venue_locations (venue_id, location_detail) VALUES
(1, 'Gate 1 - North Grand Concourse (VIP)'),
(1, 'Gate 3 - West Ground Floor Entry'),
(1, 'Gate 5 - East Pavilion Access'),
(2, 'Main Palace Gate - Gate A'),
(2, 'VIP Lounge Green Carpet Gate'),
(3, 'Ring Road North Gate'),
(4, 'Cliffside Sunset Entrance');

-- ----------------------------------------------------------------------------
-- 2. SEED ORGANIZERS
-- ----------------------------------------------------------------------------
INSERT INTO organizer (organizer_id, name, location) VALUES
(1, 'LiveSync India Entertainment Ltd', 'Bandra West, Mumbai, Maharashtra'),
(2, 'Sonic Beats Event Corp', 'Koramangala, Bengaluru, Karnataka'),
(3, 'Heritage Stagecraft Delhi', 'Connaught Place, New Delhi, Delhi');

-- ----------------------------------------------------------------------------
-- 3. SEED CONCERTS (Including Recursive Sub-Events)
-- ----------------------------------------------------------------------------
INSERT INTO concert (concert_id, event_title, date, time, type, city, region, event_desc, status, total_attendees, category, ssn, parent_concert_id) VALUES
(1, 'Sunburn Horizon Electronic Fest 2026', '2026-11-15', '18:00:00', 'Electronic Music Festival', 'Goa', 'Western Zone', 
 'The flagship electronic music festival featuring top Indian & international bass producers, immersive spatial audio, and high-power laser staging.', 'Scheduled', 0, 'Flagship Festival', 'GST-GOA-9021', NULL);

INSERT INTO concert (concert_id, event_title, date, time, type, city, region, event_desc, status, total_attendees, category, ssn, parent_concert_id) VALUES
(2, 'Sunburn: Midnight Acoustic Chill Afterparty', '2026-11-15', '23:30:00', 'Afterparty', 'Goa', 'Western Zone', 
 'Exclusive VIP chill-out acoustic and ambient electronic session with sitar and synth fusion.', 'Scheduled', 0, 'Sub-Stage', 'GST-GOA-9021', 1);

INSERT INTO concert (concert_id, event_title, date, time, type, city, region, event_desc, status, total_attendees, category, ssn, parent_concert_id) VALUES
(3, 'Raag & Symphony: Classical Fusion Live', '2026-11-22', '19:00:00', 'Classical Fusion', 'New Delhi', 'Northern Zone', 
 'A grand fusion orchestra blending traditional Indian ragas with a 50-piece contemporary symphonic ensemble.', 'Scheduled', 0, 'Hall Premiere', 'GST-DEL-4402', NULL);

INSERT INTO concert (concert_id, event_title, date, time, type, city, region, event_desc, status, total_attendees, category, ssn, parent_concert_id) VALUES
(4, 'Bengaluru Indie Wave Festival', '2026-12-05', '18:30:00', 'Indie Rock', 'Bengaluru', 'Southern Zone', 
 'A vibrant evening with breakthrough Indian indie rock bands, Hindi acoustic ballads, and live guitars.', 'Scheduled', 0, 'Tour Stop', 'GST-BLR-8829', NULL);

SELECT setval('concert_concert_id_seq', (SELECT MAX(concert_id) FROM concert));
SELECT setval('venue_venue_id_seq', (SELECT MAX(venue_id) FROM venue));
SELECT setval('organizer_organizer_id_seq', (SELECT MAX(organizer_id) FROM organizer));

-- ----------------------------------------------------------------------------
-- 4. SEED PERFORMS_AT
-- ----------------------------------------------------------------------------
INSERT INTO performs_at (concert_id, venue_id, set_list, duration) VALUES
(1, 4, '1. Mumbai Anthem / 2. Goa Sunset Bass / 3. Dhol Drops / 4. Laser Climax', 240),
(2, 4, '1. Raga Bhairavi Ambient / 2. Acoustic Chords / 3. Sunrise Meditation', 90),
(3, 3, '1. Raga Yaman Symphony / 2. Sarod & Violin Duet / 3. Cosmos Crescendo', 150),
(4, 2, '1. Dil Mere Anthem / 2. Bangalore Rains / 3. Raaste / 4. Encore Finale', 120);

-- ----------------------------------------------------------------------------
-- 5. SEED ARTISTS & ARTIST_BOOKINGS (INR ₹)
-- ----------------------------------------------------------------------------
INSERT INTO artist (artist_id, artist_name, artist_history, rider_status) VALUES
(1, 'Nucleya Live', 'Pioneering Indian bass music producer and electronic festival headliner with multiple gold records.', 'Approved'),
(2, 'Prateek Kuhad Ensemble', 'Critically acclaimed singer-songwriter known for acoustic folk and melodic Hindi-English ballads.', 'Approved'),
(3, 'Maestro Vance & The Delhi Philharmonic', 'Acclaimed 50-piece fusion orchestra harmonizing Indian sitar, tabla, and western symphonic strings.', 'Approved'),
(4, 'The Local Train Collective', 'High-energy Hindi indie-rock quartet celebrated for stadium rock anthems and driving rhythms.', 'Approved');

SELECT setval('artist_artist_id_seq', (SELECT MAX(artist_id) FROM artist));

INSERT INTO artist_booking (booking_id, concert_id, artist_id, fee, booking_status, performance_slot) VALUES
(1, 1, 1, 450000.00, 'Confirmed', '21:00:00'),
(2, 1, 2, 220000.00, 'Confirmed', '19:00:00'),
(3, 2, 2, 85000.00,  'Confirmed', '23:45:00'),
(4, 3, 3, 350000.00, 'Confirmed', '19:30:00'),
(5, 4, 4, 180000.00, 'Confirmed', '20:30:00');

SELECT setval('artist_booking_booking_id_seq', (SELECT MAX(booking_id) FROM artist_booking));

-- ----------------------------------------------------------------------------
-- 6. SEED PROMOTION
-- ----------------------------------------------------------------------------
INSERT INTO promotion (promotion_id, organizer_id, venue_id, concert_id, target_audience, budget, promo_campaign) VALUES
(1, 1, 4, 1, 'College Students 18-30, Electronic & EDM Fans', 150000.00, 'Sunburn Goa Instagram Reels & Campus Ambassador Blitz'),
(2, 3, 3, 3, 'Classical Music Lovers, Delhi NCR Cultural Patrons', 95000.00, 'Radio City Sponsorships & Metro Station Billboards'),
(3, 2, 2, 4, 'Bengaluru Tech Workers, Indie & Indie-Rock Enthusiasts', 60000.00, 'Spotify Ads & Bengaluru Cafe Gig Posters');

SELECT setval('promotion_promotion_id_seq', (SELECT MAX(promotion_id) FROM promotion));

-- ----------------------------------------------------------------------------
-- 7. SEED PRODUCTION_GEAR & WORKS_ON_STAGE
-- ----------------------------------------------------------------------------
INSERT INTO production_gear (gear_id, organizer_id, gear_name, gear_type, quantity, condition) VALUES
(1, 1, 'L-Acoustics K2 Line Array System', 'Sound Reinforcement', 24, 'Operational'),
(2, 1, 'Claypaky Scenius Moving Spotlights', 'Stage Lighting', 40, 'Operational'),
(3, 1, 'MagicFX High-Output CO2 Stage Jets', 'Pyrotechnics / FX', 8, 'Operational'),
(4, 3, 'Sennheiser MKH 800 Classical Microphones', 'Acoustic Pickups', 32, 'Operational'),
(5, 2, 'Marshall & Orange Tube Guitar Amplifiers', 'Instrument Amplification', 8, 'Operational');

SELECT setval('production_gear_gear_id_seq', (SELECT MAX(gear_id) FROM production_gear));

INSERT INTO works_on_stage (concert_id, organizer_id, stage_role) VALUES
(1, 1, 'Lead Production Director'),
(1, 2, 'Rigging & Pyrotechnics Supervisor'),
(2, 1, 'Acoustics & Sound Engineer'),
(3, 3, 'Orchestra Stage Manager'),
(4, 2, 'Front of House Audio Technician');

-- ----------------------------------------------------------------------------
-- 8. SEED ATTENDEES & APP_USERS
-- ----------------------------------------------------------------------------
INSERT INTO attendee (attendee_id, full_name, email, preferences, renewal_count) VALUES
(1, 'Arjun Sharma', 'arjun@livesync.in', 'EDM, VIP Lounge, Front Row Bass', 4),
(2, 'Ananya Iyer', 'ananya.iyer@example.in', 'Indie Rock, Acoustic Stage, Balcony View', 2),
(3, 'Rohan Verma', 'rohan.verma@example.in', 'Classical Fusion, Center Acoustic Seating', 1),
(4, 'Pooja Patel', 'pooja.patel@example.in', 'Electronic, General Admission Standing Pit', 3),
(5, 'Kabir Mehta', 'kabir.mehta@example.in', 'Acoustic Chill-out, VIP Concourse', 1);

SELECT setval('attendee_attendee_id_seq', (SELECT MAX(attendee_id) FROM attendee));

INSERT INTO app_user (user_id, username, email, password_hash, full_name, role, attendee_id) VALUES
(1, 'admin', 'admin@livesync.in', 'admin123', 'System Administrator', 'ADMIN', NULL),
(2, 'arjun', 'arjun@livesync.in', 'user123', 'Arjun Sharma', 'USER', 1);

SELECT setval('app_user_user_id_seq', (SELECT MAX(user_id) FROM app_user));

-- Seed sample pending admin request
INSERT INTO admin_request (request_id, user_id, full_name, email, department, employee_code, reason, status) VALUES
(1, 2, 'Arjun Sharma', 'arjun@livesync.in', 'Live Operations & Staging', 'EMP-OPS-402', 'Requesting administrative privileges to oversee stage equipment, manage venue bookings, and review event financials.', 'PENDING');

SELECT setval('admin_request_request_id_seq', (SELECT MAX(request_id) FROM admin_request));

-- ----------------------------------------------------------------------------
-- 9. SEED TICKETS (INR ₹)
-- ----------------------------------------------------------------------------
INSERT INTO ticket (ticket_code, concert_id, venue_id, seat_number, price, ticket_status) VALUES
('SB-VIP-01', 1, 4, 'VIP-Deck-01', 8500.00, 'AVAILABLE'),
('SB-VIP-02', 1, 4, 'VIP-Deck-02', 8500.00, 'AVAILABLE'),
('SB-GA-101', 1, 4, 'GA-Floor-101', 2499.00, 'AVAILABLE'),
('SB-GA-102', 1, 4, 'GA-Floor-102', 2499.00, 'AVAILABLE'),
('SB-GA-103', 1, 4, 'GA-Floor-103', 2499.00, 'AVAILABLE'),
('SB-GA-104', 1, 4, 'GA-Floor-104', 2499.00, 'AVAILABLE');

INSERT INTO ticket (ticket_code, concert_id, venue_id, seat_number, price, ticket_status) VALUES
('SBA-01', 2, 4, 'Lounge-Seat-01', 1499.00, 'AVAILABLE'),
('SBA-02', 2, 4, 'Lounge-Seat-02', 1499.00, 'AVAILABLE'),
('SBA-03', 2, 4, 'Lounge-Seat-03', 1499.00, 'AVAILABLE');

INSERT INTO ticket (ticket_code, concert_id, venue_id, seat_number, price, ticket_status) VALUES
('DEL-PREM-01', 3, 3, 'Prem-Row1-Seat12', 3999.00, 'AVAILABLE'),
('DEL-PREM-02', 3, 3, 'Prem-Row1-Seat13', 3999.00, 'AVAILABLE'),
('DEL-BALC-01', 3, 3, 'Balcony-B04',      1999.00, 'AVAILABLE');

INSERT INTO ticket (ticket_code, concert_id, venue_id, seat_number, price, ticket_status) VALUES
('BLR-LAWN-01', 4, 2, 'Lawn-Pass-101', 1499.00, 'AVAILABLE'),
('BLR-LAWN-02', 4, 2, 'Lawn-Pass-102', 1499.00, 'AVAILABLE'),
('BLR-PAV-01',  4, 2, 'Pavilion-P12',   2999.00, 'AVAILABLE');

-- ----------------------------------------------------------------------------
-- 10. INITIAL BOOKINGS (CLEAN SLATE: 0 PAST BOOKINGS)
-- ----------------------------------------------------------------------------
-- All tickets initialized as AVAILABLE; booking table begins empty.

INSERT INTO gear_booking (gear_booking_id, gear_id, attendee_id, booking_purpose) VALUES
(1, 1, 1, 'VIP Lounge Spatial Sound Monitor Check'),
(2, 4, 3, 'Acoustical Feedback Sitar Tuning');

SELECT setval('gear_booking_gear_booking_id_seq', (SELECT MAX(gear_booking_id) FROM gear_booking));
