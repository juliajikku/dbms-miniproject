/**
 * LiveSync: Concert & Event Management System
 * Academic DBMS & Full-Stack Project - NoSQL Implementation (MongoDB)
 * File: nosql_schema.js
 * Description: MongoDB collection definitions, validator schemas, and sample
 *              documents for flexible Artist Riders and real-time Stage Sensor Logs.
 *              Adapted for Indian concert ecosystem (Nucleya, Prateek Kuhad, Delhi Philharmonic).
 */

// ============================================================================
// 1. COLLECTION: artist_riders
// Rationale: Every artist requires highly customized technical, stage, and 
//            hospitality riders that vary drastically across music genres.
// ============================================================================
const artistRiderValidator = {
  $jsonSchema: {
    bsonType: "object",
    required: ["artist_id", "artist_name", "technical_rider", "hospitality_rider", "last_updated"],
    properties: {
      artist_id: {
        bsonType: "int",
        description: "Foreign reference to SQL artist.artist_id - required"
      },
      artist_name: {
        bsonType: "string",
        description: "Artist display name - required"
      },
      genre: {
        bsonType: "string"
      },
      technical_rider: {
        bsonType: "object",
        required: ["audio_channels", "stage_dimensions", "gear_specs"],
        properties: {
          audio_channels: { bsonType: "int" },
          stage_dimensions: { bsonType: "string" },
          gear_specs: {
            bsonType: "array",
            items: {
              bsonType: "object",
              required: ["item", "qty"],
              properties: {
                item: { bsonType: "string" },
                qty: { bsonType: "int" },
                notes: { bsonType: "string" }
              }
            }
          },
          monitoring_type: { bsonType: "string" },
          lighting_cues: {
            bsonType: "array",
            items: { bsonType: "string" }
          }
        }
      },
      hospitality_rider: {
        bsonType: "object",
        properties: {
          dressing_rooms: { bsonType: "int" },
          dietary_restrictions: {
            bsonType: "array",
            items: { bsonType: "string" }
          },
          beverages: {
            bsonType: "array",
            items: { bsonType: "string" }
          },
          room_temperature_celsius: { bsonType: "number" }
        }
      },
      approval_status: {
        enum: ["Pending", "Approved", "Rejected", "Under Review"]
      },
      last_updated: {
        bsonType: "date"
      }
    }
  }
};

// ============================================================================
// 2. COLLECTION: stage_sensor_logs
// Rationale: Real-time, write-heavy, time-series telemetry data from stage
//            IoT decibel monitors, thermal cameras, and crowd safety sensors.
// ============================================================================
const stageSensorLogValidator = {
  $jsonSchema: {
    bsonType: "object",
    required: ["concert_id", "sensor_id", "timestamp", "metrics"],
    properties: {
      concert_id: {
        bsonType: "int",
        description: "Foreign reference to SQL concert.concert_id - required"
      },
      sensor_id: {
        bsonType: "string",
        description: "Unique hardware identifier for the sensor node - required"
      },
      location_on_stage: {
        enum: ["Stage Front / Pit", "Center Stage", "FOH Sound Booth", "Backstage Left", "Backstage Right", "Rigging Truss"]
      },
      timestamp: {
        bsonType: "date",
        description: "Sensor reading capture timestamp - required"
      },
      metrics: {
        bsonType: "object",
        required: ["decibel_db", "temperature_c"],
        properties: {
          decibel_db: {
            bsonType: "number",
            minimum: 30,
            maximum: 150,
            description: "Sound pressure level in dB"
          },
          temperature_c: {
            bsonType: "number",
            description: "Ambient stage temperature in Celsius"
          },
          humidity_percent: {
            bsonType: "number",
            minimum: 0,
            maximum: 100
          },
          co2_ppm: {
            bsonType: "number",
            description: "Air quality / pyrotechnic gas level"
          },
          pyro_safety_clear: {
            bsonType: "bool"
          }
        }
      },
      alert_status: {
        enum: ["NORMAL", "WARNING", "CRITICAL"]
      }
    }
  }
};

// ============================================================================
// 3. SAMPLE DOCUMENTS FOR NOSQL COLLECTIONS (INDIAN FESTIVAL ECOSYSTEM)
// ============================================================================
const sampleArtistRiders = [
  {
    artist_id: 1,
    artist_name: "Nucleya Live",
    genre: "Indian Bass / EDM",
    technical_rider: {
      audio_channels: 10,
      stage_dimensions: "16m x 10m heavy bass platform",
      gear_specs: [
        { item: "Pioneer CDJ-3000 Multiplayer", qty: 4, notes: "Firmware v3.0+, Pro DJ Link networked" },
        { item: "Pioneer DJM-V10 6-Channel Mixer", qty: 1, notes: "Balanced XLR Master out, isolated grounding" },
        { item: "High-power Active Subwoofer Monitor", qty: 2, notes: "Dual 18-inch stage subwoofers for physical bass response" },
        { item: "Dhol Microphones (Shure Beta 98H/C)", qty: 2, notes: "Clip-on condenser for live dhol percussion accompaniment" }
      ],
      monitoring_type: "Dual In-Ear Wireless (Sennheiser G4) + Twin 18-inch Sub Monitors",
      lighting_cues: ["Heavy strobe on drop at bar 32", "Synchronized laser sweep over crowd"]
    },
    hospitality_rider: {
      dressing_rooms: 2,
      dietary_restrictions: ["Vegetarian", "Jain options available for crew"],
      beverages: ["Fresh Tender Coconut Water (12 units)", "Masala Chai (hot flask)", "Still Mineral Water (24 bottles)"],
      room_temperature_celsius: 21.0
    },
    approval_status: "Approved",
    last_updated: new Date("2026-11-01T10:00:00Z")
  },
  {
    artist_id: 2,
    artist_name: "Prateek Kuhad Ensemble",
    genre: "Indie Acoustic / Folk",
    technical_rider: {
      audio_channels: 16,
      stage_dimensions: "14m x 9m acoustic stage",
      gear_specs: [
        { item: "Yamaha CP88 Stage Piano", qty: 1, notes: "Weighted 88 keys with dedicated sustain pedal" },
        { item: "Taylor 814ce Acoustic Guitar DI", qty: 2, notes: "Active Radial J48 DI boxes" },
        { item: "Warm Vocal Mic: Neumann KMS 105", qty: 2, notes: "Pop filter and boom stand" }
      ],
      monitoring_type: "4 Custom In-Ear Stereo Mixes",
      lighting_cues: ["Warm amber and incandescent filament bulb backdrop", "Soft pinspot on grand piano"]
    },
    hospitality_rider: {
      dressing_rooms: 1,
      dietary_restrictions: ["Organic Vegetarian"],
      beverages: ["Darjeeling First Flush Green Tea", "Honey & Ginger Water", "Espresso coffee machine"],
      room_temperature_celsius: 22.0
    },
    approval_status: "Approved",
    last_updated: new Date("2026-11-01T11:30:00Z")
  },
  {
    artist_id: 3,
    artist_name: "Maestro Vance & The Delhi Philharmonic",
    genre: "Classical Fusion Orchestra",
    technical_rider: {
      audio_channels: 48,
      stage_dimensions: "24m x 15m full acoustic shell",
      gear_specs: [
        { item: "Concert Sitar Pickup & Preamp", qty: 2, notes: "Acoustically isolated piezoceramic sensor" },
        { item: "Tabla Mic Pair (Shure SM57 + AKG C451)", qty: 2, notes: "Bayan bass pickup and Dayan treble condenser" },
        { item: "Manhasset Symphony Music Stands", qty: 55, notes: "Warm LED dimmable clip lights on all stands" }
      ],
      monitoring_type: "Acoustic Shell Reflectors + 4 Discrete In-Ear Channels for Leads",
      lighting_cues: ["3200K tungsten classical wash", "Subtle saffron & indigo backdrop transition during raga climax"]
    },
    hospitality_rider: {
      dressing_rooms: 4,
      dietary_restrictions: ["Diverse options for 50 musicians", "Nut-free catering noted"],
      beverages: ["Herbal Ayurvedic Infusions", "Warm Lemon Water", "Filter Coffee"],
      room_temperature_celsius: 22.5
    },
    approval_status: "Approved",
    last_updated: new Date("2026-11-01T14:15:00Z")
  }
];

const sampleStageSensorLogs = [
  {
    concert_id: 1,
    sensor_id: "SENSOR-GOA-FOH-01",
    location_on_stage: "FOH Sound Booth",
    timestamp: new Date("2026-11-01T20:30:00Z"),
    metrics: {
      decibel_db: 98.4,
      temperature_c: 27.2,
      humidity_percent: 65,
      co2_ppm: 620,
      pyro_safety_clear: true
    },
    alert_status: "NORMAL"
  },
  {
    concert_id: 1,
    sensor_id: "SENSOR-GOA-PIT-02",
    location_on_stage: "Stage Front / Pit",
    timestamp: new Date("2026-11-01T20:30:05Z"),
    metrics: {
      decibel_db: 104.2,
      temperature_c: 29.5,
      humidity_percent: 70,
      co2_ppm: 780,
      pyro_safety_clear: true
    },
    alert_status: "WARNING"
  },
  {
    concert_id: 1,
    sensor_id: "SENSOR-GOA-RIG-03",
    location_on_stage: "Rigging Truss",
    timestamp: new Date("2026-11-01T20:30:10Z"),
    metrics: {
      decibel_db: 88.0,
      temperature_c: 31.0,
      humidity_percent: 60,
      co2_ppm: 550,
      pyro_safety_clear: true
    },
    alert_status: "NORMAL"
  }
];

module.exports = {
  artistRiderValidator,
  stageSensorLogValidator,
  sampleArtistRiders,
  sampleStageSensorLogs
};
