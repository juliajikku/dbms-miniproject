/**
 * LiveSync India: Concert & Event Management System
 * Production-Ready Backend API
 * File: server.js
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

try { require('dotenv').config(); } catch (e) {}

const db = require('./database/db');
const PORT = process.env.PORT || 3000;

let expressApp = null;
try {
  const express = require('express');
  const cors = require('cors');
  const app = express();

  app.use(cors());
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  registerExpressRoutes(app);
  expressApp = app;
} catch (e) {}

function registerExpressRoutes(app) {
  // Authentication & Registration
  app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, error: 'Username/Email and password are required.' });
    }
    const result = await db.authenticateUser(username, password);
    if (result.success) res.json(result);
    else res.status(401).json(result);
  });

  app.post('/api/auth/register', async (req, res) => {
    const { username, email, password, fullName, preferences } = req.body;
    if (!username || !email || !password || !fullName) {
      return res.status(400).json({ success: false, error: 'Full name, email, username, and password are required.' });
    }
    const result = await db.registerUser({ username, email, password, fullName, preferences });
    if (result.success) res.json(result);
    else res.status(400).json(result);
  });

  // Admin Access Request Workflow
  app.post('/api/auth/request-admin', async (req, res) => {
    try {
      const created = await db.createAdminRequest(req.body);
      res.json({ success: true, message: 'Admin approval request submitted successfully.', data: created });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/admin/requests', async (req, res) => {
    try {
      const requests = await db.getAdminRequests();
      res.json({ success: true, data: requests });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/admin/requests/:id/approve', async (req, res) => {
    try {
      const reviewerId = req.body.reviewerId || 1;
      const result = await db.approveAdminRequest(req.params.id, reviewerId);
      res.json(result);
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Concerts & Venues
  app.get('/api/concerts', async (req, res) => {
    try { res.json({ success: true, data: await db.getConcerts() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('/api/concerts/:id', async (req, res) => {
    try {
      const concert = await db.getConcertById(req.params.id);
      if (!concert) return res.status(404).json({ success: false, error: 'Event not found' });
      res.json({ success: true, data: concert });
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('/api/concerts/:id/tickets', async (req, res) => {
    try { res.json({ success: true, data: await db.getTicketsForConcert(req.params.id) }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Create Concert & Venue (Admin)
  app.post('/api/concerts', async (req, res) => {
    try {
      const result = await db.createConcert(req.body);
      res.json(result);
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('/api/attendees', async (req, res) => {
    try { res.json({ success: true, data: await db.getAttendees() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('/api/venues', async (req, res) => {
    try { res.json({ success: true, data: await db.getVenues() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Ticket Booking Transaction
  app.post('/api/bookings', async (req, res) => {
    const { attendeeId, ticketCode, amount } = req.body;
    if (!attendeeId || !ticketCode) {
      return res.status(400).json({ success: false, error: 'attendeeId and ticketCode required' });
    }
    try {
      const result = await db.executeBookTicketTransaction(attendeeId, ticketCode, amount);
      if (result.success) res.json(result);
      else res.status(400).json(result);
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Personal Bookings (User)
  app.get('/api/user/bookings', async (req, res) => {
    const attendeeId = req.query.attendee_id;
    if (!attendeeId) return res.status(400).json({ success: false, error: 'attendee_id required' });
    try {
      const bookings = await db.getUserBookings(attendeeId);
      res.json({ success: true, data: bookings });
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // All Bookings (Admin)
  app.get('/api/admin/all-bookings', async (req, res) => {
    try {
      const bookings = await db.getAllBookings();
      res.json({ success: true, data: bookings });
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Concert Cancellation (Admin Stored Procedure)
  app.post('/api/concerts/:id/cancel', async (req, res) => {
    try {
      const result = await db.executeCancelConcertProcedure(req.params.id);
      if (result.success) res.json(result);
      else res.status(400).json(result);
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Financial Analytics (Admin View)
  app.get('/api/analytics', async (req, res) => {
    try { res.json({ success: true, data: await db.getConcertAnalyticsView() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Artist Riders (Admin View - NoSQL)
  app.get('/api/nosql/riders', async (req, res) => {
    try { res.json({ success: true, data: await db.getArtistRiders() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.post('/api/nosql/riders', async (req, res) => {
    try {
      const result = await db.createArtistRider(req.body);
      res.json(result);
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  // Stage Telemetry (Admin View - NoSQL)
  app.get('/api/nosql/sensors', async (req, res) => {
    try { res.json({ success: true, data: await db.getStageSensorLogs(req.query.concert_id) }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.post('/api/nosql/sensors', async (req, res) => {
    try {
      const inserted = await db.insertStageSensorLog(req.body);
      res.json({ success: true, data: inserted });
    } catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('/api/audit-logs', async (req, res) => {
    try { res.json({ success: true, data: await db.getAuditLogs() }); }
    catch (err) { res.status(500).json({ success: false, error: err.message }); }
  });

  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });
}

// Native HTTP Server Fallback
function createFallbackServer() {
  const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.json': 'application/json',
    '.png': 'image/png'
  };

  return http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const method = req.method;

    const sendJson = (statusCode, payload) => {
      res.writeHead(statusCode, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      });
      res.end(JSON.stringify(payload));
    };

    const readBody = () => new Promise((resolve) => {
      let body = '';
      req.on('data', chunk => body += chunk.toString());
      req.on('end', () => {
        try { resolve(JSON.parse(body || '{}')); }
        catch (e) { resolve({}); }
      });
    });

    if (method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      });
      return res.end();
    }

    if (pathname === '/api/auth/login' && method === 'POST') {
      const body = await readBody();
      const result = await db.authenticateUser(body.username, body.password);
      return sendJson(result.success ? 200 : 401, result);
    }

    if (pathname === '/api/auth/register' && method === 'POST') {
      const body = await readBody();
      const result = await db.registerUser(body);
      return sendJson(result.success ? 200 : 400, result);
    }

    if (pathname === '/api/auth/request-admin' && method === 'POST') {
      const body = await readBody();
      const created = await db.createAdminRequest(body);
      return sendJson(200, { success: true, data: created });
    }

    if (pathname === '/api/admin/requests' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getAdminRequests() });
    }

    const approveAdminMatch = pathname.match(/^\/api\/admin\/requests\/(\d+)\/approve$/);
    if (approveAdminMatch && method === 'POST') {
      const body = await readBody();
      const result = await db.approveAdminRequest(approveAdminMatch[1], body.reviewerId || 1);
      return sendJson(result.success ? 200 : 400, result);
    }

    if (pathname === '/api/concerts' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getConcerts() });
    }

    if (pathname === '/api/concerts' && method === 'POST') {
      const body = await readBody();
      const result = await db.createConcert(body);
      return sendJson(200, result);
    }

    const concertTicketsMatch = pathname.match(/^\/api\/concerts\/(\d+)\/tickets$/);
    if (concertTicketsMatch && method === 'GET') {
      const tickets = await db.getTicketsForConcert(concertTicketsMatch[1]);
      return sendJson(200, { success: true, data: tickets });
    }

    const cancelConcertMatch = pathname.match(/^\/api\/concerts\/(\d+)\/cancel$/);
    if (cancelConcertMatch && method === 'POST') {
      const result = await db.executeCancelConcertProcedure(cancelConcertMatch[1]);
      return sendJson(result.success ? 200 : 400, result);
    }

    if (pathname === '/api/user/bookings' && method === 'GET') {
      const bookings = await db.getUserBookings(parsedUrl.query.attendee_id);
      return sendJson(200, { success: true, data: bookings });
    }

    if (pathname === '/api/admin/all-bookings' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getAllBookings() });
    }

    if (pathname === '/api/attendees' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getAttendees() });
    }

    if (pathname === '/api/venues' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getVenues() });
    }

    if (pathname === '/api/bookings' && method === 'POST') {
      const body = await readBody();
      const result = await db.executeBookTicketTransaction(body.attendeeId, body.ticketCode, body.amount);
      return sendJson(result.success ? 200 : 400, result);
    }

    if (pathname === '/api/analytics' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getConcertAnalyticsView() });
    }

    if (pathname === '/api/nosql/riders' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getArtistRiders() });
    }

    if (pathname === '/api/nosql/riders' && method === 'POST') {
      const body = await readBody();
      const result = await db.createArtistRider(body);
      return sendJson(200, result);
    }

    if (pathname === '/api/nosql/sensors' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getStageSensorLogs(parsedUrl.query.concert_id) });
    }

    if (pathname === '/api/nosql/sensors' && method === 'POST') {
      const body = await readBody();
      const inserted = await db.insertStageSensorLog(body);
      return sendJson(200, { success: true, data: inserted });
    }

    if (pathname === '/api/audit-logs' && method === 'GET') {
      return sendJson(200, { success: true, data: await db.getAuditLogs() });
    }

    let filePath = path.join(__dirname, 'public', pathname === '/' ? 'index.html' : pathname);
    if (!fs.existsSync(filePath)) {
      filePath = path.join(__dirname, 'public', 'index.html');
    }

    const ext = path.extname(filePath);
    const contentType = mimeTypes[ext] || 'text/plain';

    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(500);
        res.end('Server Error loading asset: ' + err.message);
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
      }
    });
  });
}

// Start Server
if (expressApp) {
  expressApp.listen(PORT, () => {
    console.log(`LiveSync Server running at: http://localhost:${PORT}`);
  });
} else {
  const server = createFallbackServer();
  server.listen(PORT, () => {
    console.log(`LiveSync Server running at: http://localhost:${PORT}`);
  });
}
