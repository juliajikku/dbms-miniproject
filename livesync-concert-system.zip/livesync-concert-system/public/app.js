/**
 * LiveSync India: Concert & Event Management System
 * Production Frontend Controller (Strict 3-Color Theme & Isolated Page Navigation)
 * File: public/app.js
 */

// Global State
let currentUser = null;
let allConcerts = [];
let allAttendees = [];
let selectedConcertTickets = [];

// ============================================================================
// INITIALIZATION & ROUTING
// ============================================================================
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  checkAuthSession();

  // Listen to browser hash changes (enables bookmarks & back/forward navigation)
  window.addEventListener('hashchange', handleHashRouting);
});

function setupNavigation() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.getAttribute('data-target');
      if (targetId) {
        navigateToTab(targetId);
      }
    });
  });
}

function handleHashRouting() {
  const hash = window.location.hash.replace('#', '');
  if (!hash) return;
  const targetId = 'tab-' + hash;
  const targetSection = document.getElementById(targetId);
  if (targetSection) {
    switchTab(targetId);
  }
}

function navigateToTab(targetId) {
  // Update URL hash for clean bookmarking
  const routeName = targetId.replace('tab-', '');
  window.location.hash = routeName;
  switchTab(targetId);
}

// Switches visible page section strictly ensuring ONLY one page is displayed
function switchTab(targetId) {
  // 1. Hide all tab sections
  const allSections = document.querySelectorAll('.tab-content');
  allSections.forEach(section => {
    section.classList.remove('active');
  });

  // 2. Remove active state from all navigation buttons
  const allButtons = document.querySelectorAll('.nav-tab');
  allButtons.forEach(btn => {
    btn.classList.remove('active');
  });

  // 3. Activate the target section
  const activeSection = document.getElementById(targetId);
  if (activeSection) {
    activeSection.classList.add('active');
  }

  // 4. Activate the corresponding navigation button
  const activeBtn = document.querySelector(`.nav-tab[data-target="${targetId}"]`);
  if (activeBtn) {
    activeBtn.classList.add('active');
  }

  // 5. Scroll page smoothly to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // 6. Trigger contextual data load for the opened page
  if (targetId === 'tab-concerts') loadConcerts();
  if (targetId === 'tab-my-bookings') loadMyBookings();
  if (targetId === 'tab-all-bookings') loadAllBookings();
  if (targetId === 'tab-riders') loadArtistRiders();
  if (targetId === 'tab-telemetry') loadStageSensors();
  if (targetId === 'tab-admin-approvals') {
    loadAdminRequests();
    loadAuditLogs();
  }
}

function formatINR(amount) {
  const val = parseFloat(amount) || 0;
  return '₹' + val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ============================================================================
// AUTHENTICATION & REGISTRATION
// ============================================================================
function checkAuthSession() {
  const stored = localStorage.getItem('livesync_user');
  if (stored) {
    try {
      currentUser = JSON.parse(stored);
      showPortalView();
    } catch (e) {
      showAuthView();
    }
  } else {
    showAuthView();
  }
}

function showAuthView() {
  document.getElementById('authView').style.display = 'flex';
  document.getElementById('portalView').style.display = 'none';
  switchAuthMode('user');
}

function showPortalView() {
  document.getElementById('authView').style.display = 'none';
  document.getElementById('portalView').style.display = 'block';

  // Apply user identity to header
  document.getElementById('headerUserName').innerText = currentUser.full_name;
  const roleBadge = document.getElementById('headerUserRole');
  roleBadge.innerText = currentUser.role;

  // Role-Based UI Filtering
  const userOnlyButtons = document.querySelectorAll('.nav-user-only');
  const adminOnlyButtons = document.querySelectorAll('.nav-admin-only');

  if (currentUser.role === 'ADMIN') {
    adminOnlyButtons.forEach(btn => btn.style.display = 'inline-block');
    userOnlyButtons.forEach(btn => btn.style.display = 'none');
  } else {
    adminOnlyButtons.forEach(btn => btn.style.display = 'none');
    userOnlyButtons.forEach(btn => btn.style.display = 'inline-block');
  }

  // Handle current hash or default to concerts
  if (window.location.hash) {
    handleHashRouting();
  } else {
    navigateToTab('tab-concerts');
  }

  loadConcerts();
  loadAttendees();
}

function switchAuthMode(mode) {
  document.querySelectorAll('.auth-nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.auth-panel').forEach(p => p.classList.remove('active'));

  if (mode === 'user') {
    document.getElementById('btnAuthUser').classList.add('active');
    document.getElementById('authPanelUser').classList.add('active');
  } else if (mode === 'register') {
    document.getElementById('btnAuthRegister').classList.add('active');
    document.getElementById('authPanelRegister').classList.add('active');
  } else if (mode === 'admin') {
    document.getElementById('btnAuthAdmin').classList.add('active');
    document.getElementById('authPanelAdmin').classList.add('active');
  } else if (mode === 'request') {
    document.getElementById('btnAuthRequest').classList.add('active');
    document.getElementById('authPanelRequest').classList.add('active');
  }
}

async function handleCustomerLogin(e) {
  e.preventDefault();
  const username = document.getElementById('userLoginId').value.trim();
  const password = document.getElementById('userLoginPass').value.trim();
  const errBox = document.getElementById('userLoginErr');
  await executeLogin(username, password, errBox);
}

async function handleAdminLogin(e) {
  e.preventDefault();
  const username = document.getElementById('adminLoginId').value.trim();
  const password = document.getElementById('adminLoginPass').value.trim();
  const errBox = document.getElementById('adminLoginErr');
  await executeLogin(username, password, errBox);
}

// User Registration (Creation of new user)
async function handleRegisterSubmit(e) {
  e.preventDefault();
  const fullName = document.getElementById('regFullName').value.trim();
  const username = document.getElementById('regUsername').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value.trim();
  const preferences = document.getElementById('regPreferences').value.trim();
  const errBox = document.getElementById('regErrorBanner');
  errBox.style.display = 'none';

  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullName, username, email, password, preferences })
    });
    const result = await res.json();

    if (result.success && result.user) {
      // Account created, automatically sign in
      currentUser = result.user;
      localStorage.setItem('livesync_user', JSON.stringify(currentUser));
      showPortalView();
    } else {
      errBox.style.display = 'block';
      errBox.innerText = result.message || result.error || 'Failed to create account.';
    }
  } catch (err) {
    errBox.style.display = 'block';
    errBox.innerText = 'Registration error: ' + err.message;
  }
}

async function executeLogin(username, password, errBox) {
  errBox.style.display = 'none';
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const result = await res.json();

    if (result.success && result.user) {
      currentUser = result.user;
      localStorage.setItem('livesync_user', JSON.stringify(currentUser));
      showPortalView();
    } else {
      errBox.style.display = 'block';
      errBox.innerText = result.message || 'Invalid username or password.';
    }
  } catch (err) {
    errBox.style.display = 'block';
    errBox.innerText = 'Connection error: ' + err.message;
  }
}

function handleLogout() {
  currentUser = null;
  localStorage.removeItem('livesync_user');
  window.location.hash = '';
  showAuthView();
}

// Admin Elevation Request Submission
async function handleAdminRequestSubmit(e) {
  e.preventDefault();
  const banner = document.getElementById('reqStatusBanner');
  banner.style.display = 'none';

  const payload = {
    userId: currentUser ? currentUser.user_id : 2,
    fullName: document.getElementById('reqFullName').value.trim(),
    email: document.getElementById('reqEmail').value.trim(),
    department: document.getElementById('reqDepartment').value.trim(),
    employeeCode: document.getElementById('reqEmpCode').value.trim(),
    reason: document.getElementById('reqReason').value.trim()
  };

  try {
    const res = await fetch('/api/auth/request-admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      banner.style.display = 'block';
      banner.innerHTML = `<strong>Request Submitted!</strong> Your elevation request (#${result.data.request_id}) is logged as PENDING. An Administrator can approve it from the Admin Portal.`;
      e.target.reset();
    }
  } catch (err) {
    alert('Failed to submit request: ' + err.message);
  }
}

// ============================================================================
// CONCERTS & VENUES
// ============================================================================
async function loadConcerts() {
  const grid = document.getElementById('concertsGrid');
  grid.innerHTML = '<div class="loading-state">Loading concert schedule...</div>';

  try {
    const res = await fetch('/api/concerts');
    const json = await res.json();
    allConcerts = json.data || [];

    const select = document.getElementById('selectConcert');
    if (select) {
      select.innerHTML = '<option value="">-- Choose Concert --</option>';
    }

    // Populate venue options for Add Concert Modal
    const venueSelect = document.getElementById('newConcertVenueSelect');
    if (venueSelect) {
      try {
        const vRes = await fetch('/api/venues');
        const vJson = await vRes.json();
        const venues = vJson.data || [];
        venueSelect.innerHTML = '<option value="">-- Choose Existing Venue or Create New --</option>';
        venues.forEach(v => {
          const opt = document.createElement('option');
          opt.value = v.venue_id;
          opt.textContent = `${v.venue_name} (${v.locations || 'India'}) - Cap: ${v.max_capacity}`;
          venueSelect.appendChild(opt);
        });
        const newOpt = document.createElement('option');
        newOpt.value = 'NEW';
        newOpt.textContent = '+ Create & Register New Venue...';
        venueSelect.appendChild(newOpt);
      } catch (ve) {
        console.error('Error loading venues:', ve);
      }
    }

    if (allConcerts.length === 0) {
      grid.innerHTML = '<div class="card">No active events found.</div>';
      return;
    }

    grid.innerHTML = '';
    allConcerts.forEach(c => {
      if (select) {
        const opt = document.createElement('option');
        opt.value = c.concert_id;
        opt.textContent = `${c.event_title} (${c.city})`;
        select.appendChild(opt);
      }

      const card = document.createElement('div');
      card.className = 'card concert-card';

      const parentTag = c.parent_event_title 
        ? `<div class="sub-event-tag">Sub-Event of: <strong>${escapeHtml(c.parent_event_title)}</strong></div>` 
        : '';

      let adminControls = '';
      if (currentUser && currentUser.role === 'ADMIN' && c.status !== 'Cancelled') {
        adminControls = `
          <button class="btn btn-danger btn-sm" onclick="triggerConcertCancellation(${c.concert_id}, '${escapeHtml(c.event_title)}')">
            Cancel Event
          </button>
        `;
      }

      let userBookBtn = '';
      if (currentUser && currentUser.role === 'USER') {
        userBookBtn = `
          <button class="btn btn-primary btn-sm" onclick="quickSelectConcertForBooking(${c.concert_id})">
            Book Seats
          </button>
        `;
      }

      card.innerHTML = `
        <div>
          <div class="card-title-row">
            <h3>${escapeHtml(c.event_title)}</h3>
            <span class="badge">${c.status}</span>
          </div>
          ${parentTag}
          <p class="concert-desc">${escapeHtml(c.event_desc || '')}</p>
          <div class="concert-meta-list">
            <div class="meta-item">📍 <strong>Venue:</strong> ${escapeHtml(c.venue_name || 'TBD')} &bull; Capacity: ${c.max_capacity}</div>
            <div class="meta-item">📅 <strong>Date:</strong> ${c.date.substring(0, 10)} at ${c.time}</div>
            <div class="meta-item">🎟️ <strong>Confirmed Attendees:</strong> ${c.total_attendees}</div>
          </div>
        </div>
        <div class="card-actions">
          <button class="btn btn-secondary btn-sm" onclick="openTicketModal(${c.concert_id}, '${escapeHtml(c.event_title)}')">
            View Seats
          </button>
          ${userBookBtn}
          ${adminControls}
        </div>
      `;
      grid.appendChild(card);
    });
  } catch (err) {
    grid.innerHTML = `<div class="card text-danger">Error: ${err.message}</div>`;
  }
}

async function loadAttendees() {
  try {
    const res = await fetch('/api/attendees');
    const json = await res.json();
    allAttendees = json.data || [];
    const select = document.getElementById('selectAttendee');
    if (!select) return;

    select.innerHTML = '<option value="">-- Choose Profile --</option>';
    allAttendees.forEach(a => {
      const opt = document.createElement('option');
      opt.value = a.attendee_id;
      opt.textContent = `${a.full_name} (${a.email})`;
      select.appendChild(opt);
    });

    if (currentUser && currentUser.attendee_id) {
      select.value = currentUser.attendee_id;
    }
  } catch (err) {
    console.error('Failed to load attendees', err);
  }
}

function quickSelectConcertForBooking(concertId) {
  navigateToTab('tab-booking');
  const select = document.getElementById('selectConcert');
  if (select) {
    select.value = concertId;
    handleConcertChange(concertId);
  }
}

async function handleConcertChange(concertId) {
  const ticketSelect = document.getElementById('selectTicket');
  const priceDisplay = document.getElementById('ticketPriceDisplay');
  priceDisplay.style.display = 'none';

  if (!concertId) {
    ticketSelect.innerHTML = '<option value="">-- Select Concert First --</option>';
    return;
  }

  ticketSelect.innerHTML = '<option value="">Loading available seats...</option>';

  try {
    const res = await fetch(`/api/concerts/${concertId}/tickets`);
    const json = await res.json();
    selectedConcertTickets = json.data || [];

    const available = selectedConcertTickets.filter(t => t.ticket_status === 'AVAILABLE');
    if (available.length === 0) {
      ticketSelect.innerHTML = '<option value="">No available seats (Sold Out / Cancelled)</option>';
      return;
    }

    ticketSelect.innerHTML = '<option value="">-- Choose Available Seat --</option>';
    available.forEach(t => {
      const opt = document.createElement('option');
      opt.value = t.ticket_code;
      opt.textContent = `Seat ${t.seat_number} - ${formatINR(t.price)} (${t.ticket_code})`;
      opt.dataset.price = t.price;
      ticketSelect.appendChild(opt);
    });

    ticketSelect.onchange = () => {
      const selected = ticketSelect.options[ticketSelect.selectedIndex];
      if (selected && selected.dataset.price) {
        priceDisplay.style.display = 'flex';
        document.getElementById('priceValue').innerText = formatINR(selected.dataset.price);
      } else {
        priceDisplay.style.display = 'none';
      }
    };
  } catch (err) {
    ticketSelect.innerHTML = `<option value="">Error: ${err.message}</option>`;
  }
}

// ============================================================================
// TICKET BOOKING (User)
// ============================================================================
async function handleBookingSubmit(event) {
  event.preventDefault();
  const attendeeId = document.getElementById('selectAttendee').value;
  const ticketSelect = document.getElementById('selectTicket');
  const ticketCode = ticketSelect.value;
  const selectedOption = ticketSelect.options[ticketSelect.selectedIndex];
  const amount = selectedOption ? selectedOption.dataset.price : 0;
  const banner = document.getElementById('bookingResultBanner');

  if (!attendeeId || !ticketCode) {
    alert('Please select both an attendee profile and an available seat.');
    return;
  }

  try {
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ attendeeId, ticketCode, amount })
    });
    const result = await res.json();

    if (result.success) {
      banner.className = 'result-banner success';
      banner.style.display = 'block';
      banner.innerHTML = `<strong>Booking Confirmed!</strong> Seat reservation successful. Booking ID: #${result.bookingId}`;

      loadConcerts();
      if (currentUser && currentUser.attendee_id) loadMyBookings();
      handleConcertChange(document.getElementById('selectConcert').value);
    } else {
      banner.className = 'result-banner error';
      banner.style.display = 'block';
      banner.innerHTML = `<strong>Booking Failed:</strong> ${result.error || result.message}`;
    }
  } catch (err) {
    banner.className = 'result-banner error';
    banner.style.display = 'block';
    banner.innerHTML = `<strong>Error:</strong> ${err.message}`;
  }
}

// ============================================================================
// PERSONAL BOOKINGS (User)
// ============================================================================
async function loadMyBookings() {
  if (!currentUser || !currentUser.attendee_id) return;
  const tbody = document.getElementById('myBookingsBody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading your tickets...</td></tr>';

  try {
    const res = await fetch(`/api/user/bookings?attendee_id=${currentUser.attendee_id}`);
    const json = await res.json();
    const list = json.data || [];

    if (list.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center">No bookings found for your account.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    list.forEach(b => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>#${b.booking_id}</strong></td>
        <td>${escapeHtml(b.event_title)}</td>
        <td>${b.concert_date ? b.concert_date.substring(0, 10) : ''} at ${b.concert_time || ''}</td>
        <td>Seat <strong>${b.seat_number}</strong> (${b.ticket_code})</td>
        <td>${escapeHtml(b.venue_name)}, ${b.city}</td>
        <td><strong>${formatINR(b.total_amount)}</strong></td>
        <td><span class="badge">${b.payment_status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Error: ${err.message}</td></tr>`;
  }
}

// ============================================================================
// MASTER TICKETING REGISTRY (Admin)
// ============================================================================
async function loadAllBookings() {
  const tbody = document.getElementById('allBookingsBody');
  tbody.innerHTML = '<tr><td colspan="8" class="text-center">Loading master ticketing registry...</td></tr>';

  try {
    const res = await fetch('/api/admin/all-bookings');
    const json = await res.json();
    const list = json.data || [];

    if (list.length === 0) {
      tbody.innerHTML = '<tr><td colspan="8" class="text-center">No purchases recorded.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    list.forEach(b => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>#${b.booking_id}</td>
        <td><strong>${escapeHtml(b.attendee_name)}</strong><br><small class="text-muted">${escapeHtml(b.attendee_email)}</small></td>
        <td>${escapeHtml(b.event_title)}</td>
        <td>${escapeHtml(b.venue_name)}, ${b.city}</td>
        <td>Seat <strong>${b.seat_number}</strong></td>
        <td><strong>${formatINR(b.total_amount)}</strong></td>
        <td>${new Date(b.booking_date).toLocaleDateString()}</td>
        <td><span class="badge">${b.payment_status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">Error: ${err.message}</td></tr>`;
  }
}

// ============================================================================
// ADMIN CARD CREATION: CONCERTS & VENUES
// ============================================================================
function openAddConcertModal() {
  const modal = document.getElementById('addConcertModal');
  if (!modal) return;
  modal.style.display = 'flex';
  const errBox = document.getElementById('addConcertError');
  if (errBox) errBox.style.display = 'none';

  // Set default date to tomorrow if empty
  const dateInput = document.getElementById('newConcertDate');
  if (dateInput && !dateInput.value) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 14);
    dateInput.value = tomorrow.toISOString().substring(0, 10);
  }
}

function closeAddConcertModal() {
  const modal = document.getElementById('addConcertModal');
  if (modal) modal.style.display = 'none';
}

function handleConcertVenueChange(val) {
  const customBox = document.getElementById('newVenueCustomFields');
  if (customBox) {
    customBox.style.display = (val === 'NEW') ? 'block' : 'none';
  }
}

async function handleAddConcertSubmit(e) {
  e.preventDefault();
  const errBox = document.getElementById('addConcertError');
  if (errBox) errBox.style.display = 'none';

  const venueSelectVal = document.getElementById('newConcertVenueSelect').value;
  if (!venueSelectVal) {
    errBox.style.display = 'block';
    errBox.innerText = 'Please select a venue or choose "+ Create New Venue".';
    return;
  }

  const payload = {
    event_title: document.getElementById('newConcertTitle').value.trim(),
    date: document.getElementById('newConcertDate').value,
    time: document.getElementById('newConcertTime').value,
    type: document.getElementById('newConcertType').value.trim(),
    city: document.getElementById('newConcertCity').value.trim(),
    region: document.getElementById('newConcertRegion').value.trim(),
    event_desc: document.getElementById('newConcertDesc').value.trim(),
    venue_id: venueSelectVal,
    new_venue_name: document.getElementById('newVenueName') ? document.getElementById('newVenueName').value.trim() : '',
    new_venue_capacity: document.getElementById('newVenueCapacity') ? document.getElementById('newVenueCapacity').value : 10000,
    new_venue_locations: document.getElementById('newVenueLocations') ? document.getElementById('newVenueLocations').value.trim() : '',
    ticket_price: document.getElementById('newConcertPrice').value,
    ticket_count: document.getElementById('newConcertSeatsCount').value
  };

  try {
    const res = await fetch('/api/concerts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      closeAddConcertModal();
      document.getElementById('addConcertForm').reset();
      handleConcertVenueChange('');
      await loadConcerts();
      alert(`Success! "${payload.event_title}" concert card and seats have been created.`);
    } else {
      errBox.style.display = 'block';
      errBox.innerText = result.error || 'Failed to create concert.';
    }
  } catch (err) {
    errBox.style.display = 'block';
    errBox.innerText = 'Error: ' + err.message;
  }
}

// ============================================================================
// ADMIN CARD CREATION: ARTIST RIDERS (NoSQL)
// ============================================================================
function openAddRiderModal() {
  const modal = document.getElementById('addRiderModal');
  if (!modal) return;
  modal.style.display = 'flex';
  const errBox = document.getElementById('addRiderError');
  if (errBox) errBox.style.display = 'none';
}

function closeAddRiderModal() {
  const modal = document.getElementById('addRiderModal');
  if (modal) modal.style.display = 'none';
}

async function handleAddRiderSubmit(e) {
  e.preventDefault();
  const errBox = document.getElementById('addRiderError');
  if (errBox) errBox.style.display = 'none';

  const payload = {
    artist_name: document.getElementById('newRiderArtistName').value.trim(),
    genre: document.getElementById('newRiderGenre').value.trim(),
    approval_status: document.getElementById('newRiderStatus').value,
    audio_channels: document.getElementById('newRiderChannels').value,
    stage_dimensions: document.getElementById('newRiderStageDim').value.trim(),
    monitoring_type: document.getElementById('newRiderMonitoring').value.trim(),
    gear_specs: document.getElementById('newRiderGear').value.trim(),
    dressing_rooms: document.getElementById('newRiderRooms').value,
    room_temp: document.getElementById('newRiderTemp').value,
    catering: document.getElementById('newRiderCatering').value.trim()
  };

  try {
    const res = await fetch('/api/nosql/riders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      closeAddRiderModal();
      document.getElementById('addRiderForm').reset();
      await loadArtistRiders();
      alert(`Success! Artist rider card for "${payload.artist_name}" has been registered.`);
    } else {
      errBox.style.display = 'block';
      errBox.innerText = result.error || 'Failed to save rider.';
    }
  } catch (err) {
    errBox.style.display = 'block';
    errBox.innerText = 'Error: ' + err.message;
  }
}

// ============================================================================
// ARTIST RIDERS (Admin - NoSQL)
// ============================================================================
async function loadArtistRiders() {
  const grid = document.getElementById('ridersGrid');
  grid.innerHTML = '<div class="loading-state">Loading artist specifications...</div>';

  try {
    const res = await fetch('/api/nosql/riders');
    const json = await res.json();
    const riders = json.data || [];

    if (riders.length === 0) {
      grid.innerHTML = '<div class="card">No artist specifications registered.</div>';
      return;
    }

    grid.innerHTML = '';
    riders.forEach(r => {
      const card = document.createElement('div');
      card.className = 'card rider-card';

      const gearItems = (r.technical_rider && r.technical_rider.gear_specs) 
        ? r.technical_rider.gear_specs.map(g => `<li><strong>${g.qty}x ${escapeHtml(g.item)}</strong>: ${escapeHtml(g.notes || '')}</li>`).join('')
        : '<li>Standard stage kit</li>';

      const dietItems = (r.hospitality_rider && r.hospitality_rider.dietary_restrictions)
        ? r.hospitality_rider.dietary_restrictions.join(', ')
        : 'Standard catering';

      const beverages = (r.hospitality_rider && r.hospitality_rider.beverages)
        ? r.hospitality_rider.beverages.join(', ')
        : 'Mineral Water';

      card.innerHTML = `
        <div class="card-title-row">
          <h3>${escapeHtml(r.artist_name)}</h3>
          <span class="badge">${escapeHtml(r.genre || 'Performer')}</span>
        </div>
        <p class="section-desc">Artist Code: #${r.artist_id} &bull; Status: ${r.approval_status}</p>

        <div class="rider-section">
          <h4>Technical Specifications</h4>
          <ul class="rider-specs">
            <li>Audio Channels: <strong>${r.technical_rider ? r.technical_rider.audio_channels : 4} channels</strong></li>
            <li>Stage Footprint: ${escapeHtml(r.technical_rider ? r.technical_rider.stage_dimensions : 'Standard')}</li>
            <li>Monitoring: ${escapeHtml(r.technical_rider ? r.technical_rider.monitoring_type : 'Standard IEM')}</li>
            ${gearItems}
          </ul>
        </div>

        <div class="rider-section">
          <h4>Backstage & Hospitality</h4>
          <ul class="rider-specs">
            <li>Dressing Rooms: ${r.hospitality_rider ? r.hospitality_rider.dressing_rooms : 1} suite(s)</li>
            <li>Target Room Temperature: ${r.hospitality_rider ? r.hospitality_rider.room_temperature_celsius : 21}°C</li>
            <li>Catering: ${escapeHtml(dietItems)} &bull; ${escapeHtml(beverages)}</li>
          </ul>
        </div>
      `;
      grid.appendChild(card);
    });
  } catch (err) {
    grid.innerHTML = `<div class="card text-danger">Error: ${err.message}</div>`;
  }
}

// ============================================================================
// STAGE TELEMETRY (Admin - NoSQL)
// ============================================================================
async function loadStageSensors() {
  const tbody = document.getElementById('sensorLogsBody');

  try {
    const res = await fetch('/api/nosql/sensors');
    const json = await res.json();
    const logs = json.data || [];

    if (logs.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center">No telemetry packets recorded yet.</td></tr>';
      return;
    }

    const latest = logs[0];
    if (latest && latest.metrics) {
      document.getElementById('valDecibel').innerHTML = `${latest.metrics.decibel_db} <small>dB</small>`;
      document.getElementById('valTemp').innerHTML = `${latest.metrics.temperature_c} <small>°C</small>`;
      document.getElementById('valCo2').innerHTML = `${latest.metrics.co2_ppm} <small>ppm</small>`;
      
      const pyroBadge = document.getElementById('valPyro');
      if (latest.metrics.pyro_safety_clear) {
        pyroBadge.innerText = 'CLEAR';
      } else {
        pyroBadge.innerText = 'TRIPPED';
      }
    }

    tbody.innerHTML = '';
    logs.slice(0, 10).forEach(l => {
      const tr = document.createElement('tr');
      const timeStr = new Date(l.timestamp).toLocaleTimeString();

      tr.innerHTML = `
        <td>${timeStr}</td>
        <td><code>${escapeHtml(l.sensor_id)}</code></td>
        <td>${escapeHtml(l.location_on_stage)}</td>
        <td><strong>${l.metrics.decibel_db}</strong></td>
        <td>${l.metrics.temperature_c}°C</td>
        <td>${l.metrics.co2_ppm}</td>
        <td><span class="badge">${l.alert_status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Error: ${err.message}</td></tr>`;
  }
}

async function simulateSensorReading() {
  const randomDecibel = (92 + Math.random() * 15).toFixed(1);
  const randomTemp = (25 + Math.random() * 8).toFixed(1);
  const randomCo2 = Math.floor(550 + Math.random() * 250);

  try {
    await fetch('/api/nosql/sensors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        concert_id: 1,
        sensor_id: 'SENSOR-GOA-' + Math.floor(10 + Math.random() * 90),
        location_on_stage: 'Stage Front / Pit',
        decibel_db: randomDecibel,
        temperature_c: randomTemp,
        co2_ppm: randomCo2,
        humidity_percent: 68
      })
    });
    loadStageSensors();
  } catch (err) {
    alert('Failed to transmit telemetry: ' + err.message);
  }
}

// ============================================================================
// ADMIN ELEVATION APPROVALS (Admin)
// ============================================================================
async function loadAdminRequests() {
  const tbody = document.getElementById('adminRequestsBody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading clearance requests...</td></tr>';

  try {
    const res = await fetch('/api/admin/requests');
    const json = await res.json();
    const requests = json.data || [];

    if (requests.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="text-center">No pending clearance applications.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    requests.forEach(r => {
      const tr = document.createElement('tr');
      const timeStr = new Date(r.created_at).toLocaleDateString();

      let actionCell = `<span class="badge">APPROVED</span>`;
      if (r.status === 'PENDING') {
        actionCell = `
          <button class="btn btn-primary btn-sm" onclick="approveAdminRequest(${r.request_id})">
            Approve
          </button>
        `;
      }

      tr.innerHTML = `
        <td>#${r.request_id}</td>
        <td><strong>${escapeHtml(r.full_name)}</strong></td>
        <td>${escapeHtml(r.email)}</td>
        <td>${escapeHtml(r.department)} &bull; <code>${escapeHtml(r.employee_code)}</code></td>
        <td>${escapeHtml(r.reason)}</td>
        <td>${timeStr}</td>
        <td>${actionCell}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Error: ${err.message}</td></tr>`;
  }
}

async function approveAdminRequest(requestId) {
  if (!confirm(`Authorize administrator elevation for Request #${requestId}?`)) return;

  try {
    const res = await fetch(`/api/admin/requests/${requestId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reviewerId: currentUser.user_id })
    });
    const result = await res.json();
    alert(result.message || 'Request approved successfully.');
    loadAdminRequests();
  } catch (err) {
    alert('Failed to approve request: ' + err.message);
  }
}

async function triggerConcertCancellation(concertId, title) {
  if (!confirm(`Are you sure you want to cancel "${title}"? This will automatically initiate refunds for all booked tickets.`)) {
    return;
  }

  try {
    const res = await fetch(`/api/concerts/${concertId}/cancel`, { method: 'POST' });
    const json = await res.json();
    alert(json.message || json.error);
    loadConcerts();
  } catch (err) {
    alert('Error cancelling concert: ' + err.message);
  }
}

async function loadAuditLogs() {
  const tbody = document.getElementById('auditLogsBody');
  if (!tbody) return;
  try {
    const res = await fetch('/api/audit-logs');
    const json = await res.json();
    const logs = json.data || [];

    if (logs.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="text-center">No audit logs recorded yet.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    logs.slice(0, 10).forEach(log => {
      const tr = document.createElement('tr');
      const timeStr = new Date(log.created_at).toLocaleTimeString();
      tr.innerHTML = `
        <td>#${log.log_id}</td>
        <td><span class="badge">${escapeHtml(log.action_type)}</span></td>
        <td><code>${escapeHtml(log.entity_name)}</code></td>
        <td>${escapeHtml(log.record_id || '-')}</td>
        <td>${escapeHtml(log.details)}</td>
        <td>${timeStr}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Error: ${err.message}</td></tr>`;
  }
}

// ============================================================================
// TICKET MODAL
// ============================================================================
async function openTicketModal(concertId, title) {
  document.getElementById('modalConcertTitle').innerText = `${title} - Seats`;
  const list = document.getElementById('modalTicketsList');
  list.innerHTML = '<div class="loading-state">Loading seat map...</div>';
  document.getElementById('ticketModal').style.display = 'flex';

  try {
    const res = await fetch(`/api/concerts/${concertId}/tickets`);
    const json = await res.json();
    const tickets = json.data || [];

    if (tickets.length === 0) {
      list.innerHTML = '<div>No seats listed for this event.</div>';
      return;
    }

    list.innerHTML = '';
    tickets.forEach(t => {
      const item = document.createElement('div');
      item.className = `ticket-item ${t.ticket_status !== 'AVAILABLE' ? 'booked' : ''}`;

      item.innerHTML = `
        <strong>${escapeHtml(t.seat_number)}</strong>
        <div style="font-size: 0.75rem; color: #94a3b8; margin: 0.25rem 0;">${t.ticket_code}</div>
        <div style="font-weight: bold;">${formatINR(t.price)}</div>
        <div style="margin-top: 0.35rem;"><span class="badge">${t.ticket_status}</span></div>
      `;
      list.appendChild(item);
    });
  } catch (err) {
    list.innerHTML = `<div class="text-danger">Error: ${err.message}</div>`;
  }
}

function closeTicketModal() {
  document.getElementById('ticketModal').style.display = 'none';
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
